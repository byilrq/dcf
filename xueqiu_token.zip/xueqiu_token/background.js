const DEFAULT_ALARM_NAME = 'dcf_xueqiu_cookie_daily_check';
const DEFAULT_CHECK_MINUTES = 24 * 60;

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(DEFAULT_ALARM_NAME, { delayInMinutes: 1, periodInMinutes: DEFAULT_CHECK_MINUTES });
  checkAndMaybePush('installed').catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(DEFAULT_ALARM_NAME, { delayInMinutes: 1, periodInMinutes: DEFAULT_CHECK_MINUTES });
  checkAndMaybePush('browser_startup').catch(() => {});
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm && alarm.name === DEFAULT_ALARM_NAME) {
    checkAndMaybePush('daily_alarm').catch(() => {});
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'GET_XUEQIU_COOKIE') {
    getXueqiuCookieHeader().then((result) => sendResponse(result)).catch((error) => sendResponse({ ok: false, message: String(error?.message || error) }));
    return true;
  }
  if (message?.type === 'SAVE_SETTINGS') {
    saveSettings(message.settings || {}).then((result) => sendResponse(result)).catch((error) => sendResponse({ ok: false, message: String(error?.message || error) }));
    return true;
  }
  if (message?.type === 'GET_SETTINGS') {
    getSettings().then((settings) => sendResponse({ ok: true, settings })).catch((error) => sendResponse({ ok: false, message: String(error?.message || error) }));
    return true;
  }
  if (message?.type === 'PUSH_NOW') {
    checkAndMaybePush('manual_push', true).then((result) => sendResponse(result)).catch((error) => sendResponse({ ok: false, message: String(error?.message || error) }));
    return true;
  }
});

async function getSettings() {
  return await chrome.storage.local.get({ dcfEndpoint: '', apiKey: '', lastToken: '', lastCookieHeader: '', lastLocalUpdatedAt: '', lastPushAt: '', lastPushMessage: '' });
}

async function saveSettings(settings) {
  const dcfEndpoint = normalizeEndpoint(settings.dcfEndpoint || '');
  const apiKey = String(settings.apiKey || '').trim();
  await chrome.storage.local.set({ dcfEndpoint, apiKey });
  return { ok: true, settings: await getSettings(), message: '设置已保存。' };
}

function normalizeEndpoint(value) {
  let text = String(value || '').trim();
  if (!text) return '';
  text = text.replace(/\/+$/, '');
  if (!/\/tokenapi$/i.test(text)) text += '/tokenapi';
  return text;
}

async function checkAndMaybePush(reason, forcePush = false) {
  const cookieResult = await getXueqiuCookieHeader();
  if (!cookieResult.ok) return cookieResult;
  const settings = await getSettings();
  const tokenChanged = (cookieResult.token || '') !== (settings.lastToken || '');
  const cookieChanged = (cookieResult.cookieHeader || '') !== (settings.lastCookieHeader || '');
  const changed = tokenChanged || cookieChanged;
  const now = new Date().toISOString();
  if (changed) {
    await chrome.storage.local.set({ lastToken: cookieResult.token || '', lastCookieHeader: cookieResult.cookieHeader || '', lastLocalUpdatedAt: now });
  }
  if (!settings.dcfEndpoint || !settings.apiKey) {
    return { ok: true, changed, pushed: false, token: cookieResult.token || '', cookieHeader: cookieResult.cookieHeader || '', count: cookieResult.count || 0, message: changed ? '本地 Cookie 已更新；尚未配置 DCF 接口或 API 密钥。' : '本地 Cookie 未变化；尚未配置 DCF 接口或 API 密钥。' };
  }
  if (!changed && !forcePush) {
    return { ok: true, changed: false, pushed: false, token: cookieResult.token || '', cookieHeader: cookieResult.cookieHeader || '', count: cookieResult.count || 0, message: '本地 Cookie 未变化，未推送。' };
  }
  const pushResult = await pushToDcf(settings.dcfEndpoint, settings.apiKey, cookieResult, reason);
  await chrome.storage.local.set({ lastPushAt: now, lastPushMessage: pushResult.message || '' });
  return { ...cookieResult, changed, pushed: true, push: pushResult, message: pushResult.message || '已推送到 DCF。' };
}

async function pushToDcf(endpoint, apiKey, cookieResult, reason) {
  const payload = {
    token: cookieResult.token || '',
    cookie: cookieResult.cookieHeader || '',
    cookieHeader: cookieResult.cookieHeader || '',
    source: 'xueqiu_browser_extension:' + reason,
    client_updated_at: new Date().toISOString(),
  };
  const resp = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-DCF-TokenAPI-Key': apiKey },
    body: JSON.stringify(payload),
  });
  let data = null;
  try { data = await resp.json(); } catch (e) {}
  if (!resp.ok || !data?.ok) throw new Error((data && data.message) || ('推送失败 HTTP ' + resp.status));
  return data;
}

async function getXueqiuCookieHeader() {
  const activeUrls = await getActiveXueqiuUrls();
  const queries = [
    ...activeUrls.map((url) => ({ url })),
    { url: 'https://xueqiu.com/' },
    { url: 'https://stock.xueqiu.com/' },
    { url: 'https://xueqiu.com/S/SH000001' },
    { domain: 'xueqiu.com' },
    { domain: '.xueqiu.com' },
    { domain: 'stock.xueqiu.com' },
    { domain: '.stock.xueqiu.com' }
  ];
  const all = [];
  const errors = [];
  for (const query of queries) {
    try { all.push(...await chrome.cookies.getAll(query)); }
    catch (error) { errors.push(`${JSON.stringify(query)}: ${String(error?.message || error)}`); }
  }
  const byName = new Map();
  for (const c of all) {
    if (!c?.name) continue;
    const domain = String(c.domain || '').replace(/^\./, '');
    if (!/(^|\.)xueqiu\.com$/i.test(domain)) continue;
    const existing = byName.get(c.name);
    if (!existing || String(c.domain || '').length > String(existing.domain || '').length) byName.set(c.name, c);
  }
  const important = ['xq_a_token', 'xqat', 'u', 'xq_is_login', 'xq_id_token', 'device_id', 'xq_r_token', 'Hm_lvt_1db88642e346389874251b5a1eded6e3', 'Hm_lpvt_1db88642e346389874251b5a1eded6e3'];
  const cookies = [...byName.values()].sort((a, b) => {
    const ai = important.indexOf(a.name);
    const bi = important.indexOf(b.name);
    if (ai !== bi) return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
    return String(a.name).localeCompare(String(b.name));
  });
  const tokenCookie = byName.get('xq_a_token');
  const parts = cookies.map((c) => `${c.name}=${c.value}`);
  if (!parts.length) {
    return { ok: false, count: 0, token: '', cookieHeader: '', message: errors.length ? `没有读取到雪球 Cookie。错误：${errors.join(' | ')}` : '没有读取到雪球 Cookie。请先打开 xueqiu.com 并登录，再点击获取。' };
  }
  return { ok: true, count: parts.length, token: tokenCookie ? tokenCookie.value : '', cookieHeader: parts.join('; '), message: tokenCookie ? '已获取 xq_a_token 和完整 Cookie。' : '已获取 Cookie，但没有发现 xq_a_token；可复制完整 Cookie 使用。' };
}

async function getActiveXueqiuUrls() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs.map((tab) => tab.url || '').filter((url) => /^https?:\/\/([^/]+\.)?xueqiu\.com(\/|$)/i.test(url));
  } catch (error) { return []; }
}

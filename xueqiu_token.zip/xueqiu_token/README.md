# 雪球 Token 提取助手 + DCF 自动推送

用途：从当前 Chrome/Edge 登录状态读取雪球 `xq_a_token` 与完整 Cookie，保存到浏览器本地；当浏览器启动、每日定时检查或手动点击“立即推送”时，如果 Cookie/Token 有变化，会推送到 DCF 服务器 `/tokenapi`。

## 安装

1. 打开 Chrome/Edge 扩展管理页。
2. 开启“开发者模式”。
3. 选择“加载已解压的扩展程序”，选择本目录。
4. 在同一浏览器打开 https://xueqiu.com 并登录。

## DCF 推送设置

在插件中填写：

- 接口地址：`https://sharq.eu.org:819/tokenapi`
- API 密钥：服务器 `/root/dcf/web_portal.json` 里的 `token_api_key`

查看 API 密钥：

```bash
python -c "import json; print(json.load(open('/root/dcf/web_portal.json')).get('token_api_key'))"
```

## 自动更新逻辑

- 浏览器启动后自动检查一次。
- 每 24 小时自动检查一次。
- 点击“获取”只读取显示。
- 点击“立即推送”会强制推送一次。
- 自动检查发现 Cookie/Token 变化时，才会推送到 DCF。

插件只读取雪球 Cookie；只会向你配置的 DCF `/tokenapi` 推送。

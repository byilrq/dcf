#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import csv
import math
import json
import argparse
import logging
from pathlib import Path
from datetime import datetime, timedelta

import pandas as pd
import yfinance as yf


# ===========================
# 配置读取
# ===========================
def load_config(path: str):
    """
    读取 dcf.yaml（优先用 pyyaml；没有则尝试 json5）
    返回：ETF_CONFIG, STRATEGY 两个 dict
    """
    try:
        import yaml
    except ImportError:
        import json5 as json_mod
        with open(path, "r", encoding="utf-8") as f:
            cfg = json_mod.load(f)
    else:
        with open(path, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f)

    dcf_cfg = cfg.get("ETF_CONFIG", {}) or {}
    strategy_cfg = cfg.get("STRATEGY", {}) or {}
    common_cfg = cfg.get("COMMON_BACKTEST_CONFIG", {}) or {}
    return dcf_cfg, strategy_cfg, common_cfg


# ===========================
# 符号映射
# ===========================
def normalize_symbol(symbol: str) -> str:
    return symbol.upper().strip()


def to_yahoo_symbol(symbol: str) -> str:
    """
    SH600519 -> 600519.SS
    SZ000001 -> 000001.SZ
    HK00700  -> 0700.HK
    """
    s = normalize_symbol(symbol)

    if s.startswith("SH"):
        return f"{s[2:]}.SS"
    if s.startswith("SZ"):
        return f"{s[2:]}.SZ"
    if s.startswith("HK"):
        code = s[2:].strip()
        code = code.zfill(4)[-4:]
        return f"{code}.HK"

    raise ValueError(f"不支持的 symbol: {symbol}，仅支持 SHxxxxxx / SZxxxxxx / HKxxxxx")


# ===========================
# 工具函数
# ===========================
POSITION_EPSILON = 1e-9


def round_to_lot(qty: int, lot_size: int = 100) -> int:
    if qty <= 0:
        return 0
    rounded_qty = int(qty // lot_size) * lot_size
    if rounded_qty == 0 and qty > 0:
        rounded_qty = lot_size
    return rounded_qty


def calculate_new_avg_cost(old_position, old_avg_cost, add_units, add_price):
    if old_position <= 0:
        return add_price
    total_cost_before = old_position * old_avg_cost
    total_cost_after = total_cost_before + add_units * add_price
    return total_cost_after / (old_position + add_units)


def _safe_float(value, default=0.0):
    try:
        if isinstance(value, str):
            value = value.strip()
            if not value:
                return default
        return float(value)
    except Exception:
        return default




def get_box_grid_enabled(cfg):
    value = str((cfg or {}).get("box_grid_enabled", "no")).strip().lower()
    return value in {"yes", "true", "1", "on"}

def get_position_mode(cfg):
    base = cfg.get("base_units", 0)
    target = cfg.get("target_units", 0)

    if isinstance(base, str) and base.strip().endswith("%"):
        return "percent"
    if isinstance(target, str) and target.strip().endswith("%"):
        return "percent"

    try:
        base_f = float(base)
        target_f = float(target)
        if 0 <= base_f <= 1 and 0 <= target_f <= 1:
            return "percent"
    except Exception:
        pass

    return "absolute"


def parse_position_value(value, mode=None):
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return 0.0
        if s.endswith("%"):
            return float(s[:-1]) / 100.0
        return float(s)
    return _safe_float(value, 0.0)


def get_base_units(cfg):
    mode = get_position_mode(cfg)
    return parse_position_value(cfg.get("base_units", 0), mode)


def get_target_units(cfg):
    mode = get_position_mode(cfg)
    return parse_position_value(cfg.get("target_units", 0), mode)


def get_double_target(cfg):
    return get_target_units(cfg) * _safe_float(cfg.get("double_target_factor", 2.0), 2.0)


def normalize_position_amount(value, mode, lot_size=100):
    value = max(_safe_float(value, 0.0), 0.0)
    if mode == "percent":
        if value <= POSITION_EPSILON:
            return 0.0
        return round(value, 6)
    return round_to_lot(value, lot_size)


def format_percent_ratio(value, digits=2):
    pct = _safe_float(value, 0.0) * 100.0
    s = f"{pct:.{digits}f}".rstrip("0").rstrip(".")
    if s in {"", "-0"}:
        s = "0"
    return f"{s}%"


def format_units_for_display(value, mode):
    if mode == "percent":
        return format_percent_ratio(value)
    return f"{int(round(_safe_float(value, 0.0))):,}股"


def format_trade_rate_display(rate):
    return format_percent_ratio(rate)


def serialize_numeric(value, digits=6):
    if value is None or value == "":
        return ""
    if isinstance(value, str):
        return value
    s = f"{float(value):.{digits}f}".rstrip("0").rstrip(".")
    return s if s else "0"


def get_step_trade_units(cfg, pct_key, step_diff=1, lot_size=100):
    mode = get_position_mode(cfg)
    pct = max(_safe_float(cfg.get(pct_key, 0.0), 0.0), 0.0)
    reference = get_base_units(cfg) if mode == "percent" else get_target_units(cfg)
    return normalize_position_amount(reference * pct * step_diff, mode, lot_size)


def get_step_trade_display(cfg, pct_key, step_diff=1):
    pct = max(_safe_float(cfg.get(pct_key, 0.0), 0.0), 0.0)
    return format_trade_rate_display(pct * step_diff)


def get_total_value(cash, units, avg_cost, price, mode):
    if mode == "absolute":
        return cash + units * price
    if units <= POSITION_EPSILON:
        return cash
    if avg_cost > 0:
        return cash + units * price / avg_cost
    return cash + units


def get_market_weight(units, avg_cost, price, mode):
    if mode == "absolute":
        return units * price
    if units <= POSITION_EPSILON:
        return 0.0
    if avg_cost > 0:
        return units * price / avg_cost
    return units


# ===========================
# MA计算 & 横盘评分
# ===========================
def calc_ma_with_coef(closes, length, min_coef=None, reference_ma=None):
    """
    计算移动均线（历史不足时做退化处理）
    返回：(ma_value, source)
    source: f full / p partial / c coef / insufficient_data
    """
    if len(closes) >= length:
        ma_value = sum(closes[-length:]) / length
        return ma_value, 'p' if len(closes) < length * 2 else 'f'
    elif len(closes) >= max(5, length // 2):
        ma_value = sum(closes) / len(closes)
        return ma_value, 'p'
    elif min_coef is not None and reference_ma is not None:
        ma_value = reference_ma * min_coef
        return ma_value, 'c'
    else:
        return None, 'insufficient_data'


def _compute_ma_series(closes, period):
    if len(closes) < period:
        return []
    ma_series = []
    window_sum = sum(closes[:period])
    ma_series.append(window_sum / period)
    for i in range(period, len(closes)):
        window_sum += closes[i] - closes[i - period]
        ma_series.append(window_sum / period)
    return ma_series


def _ma_directional_sideways_score(ma_series, window):
    n = len(ma_series)
    if n < window + 1:
        return 0.5
    seg = ma_series[-(window + 1):]
    deltas = [seg[i + 1] - seg[i] for i in range(window)]
    sum_abs = sum(abs(d) for d in deltas)
    if sum_abs == 0:
        return 1.0
    dir_strength = abs(sum(deltas)) / sum_abs
    sideways_score = 1.0 - dir_strength
    return max(0.0, min(1.0, sideways_score))


def compute_sideways_index(closes, cfg):
    period30 = 30
    period60 = 60
    window30 = int(cfg.get("sideways_window_30", 30))
    window60 = int(cfg.get("sideways_window_60", 20))
    weight60 = _safe_float(cfg.get("sideways_weight_60", 0.6), 0.6)
    weight60 = max(0.0, min(1.0, weight60))
    weight30 = 1.0 - weight60

    need_len = max(period30 + window30 + 1, period60 + window60 + 1)
    if len(closes) < need_len:
        return 0.0

    ma30_series = _compute_ma_series(closes, period30)
    ma60_series = _compute_ma_series(closes, period60)
    if not ma30_series or not ma60_series:
        return 0.0

    s30 = _ma_directional_sideways_score(ma30_series, window30)
    s60 = _ma_directional_sideways_score(ma60_series, window60)
    sideways_score = weight30 * s30 + weight60 * s60
    return max(0.0, min(1.0, sideways_score))


# ===========================
# 区间判断
# ===========================
def get_box_upper_multiple(cfg):
    value = _safe_float(cfg.get("core_zone_upper_multiple", 1.2), 1.2)
    if value <= 0:
        return 1.2
    return value if value >= 1.0 else 1.0 + value


def get_core_sell_start_multiple(cfg):
    return _safe_float(cfg.get("core_sell_start_multiple", 1.5), 1.5)


def get_core_sell_step_percent(cfg):
    step = _safe_float(cfg.get("core_sell_step_percent", 0.08), 0.08)
    return max(step, 1e-6)


def calculate_core_sell_plan(cfg, target_units, lot_size=100):
    pyramid_weights = cfg.get(
        "pyramid_weights",
        [0.03, 0.055, 0.08, 0.105, 0.13, 0.155, 0.18, 0.205, 0.23, 0.255]
    )
    mode = get_position_mode(cfg)
    total_core_units = max(target_units, 0.0)
    if total_core_units <= POSITION_EPSILON:
        return []

    weight_sum = sum(pyramid_weights)
    normalized_weights = [w / weight_sum for w in pyramid_weights]

    sell_plan = []
    for i, w in enumerate(normalized_weights):
        sell_units = normalize_position_amount(total_core_units * w, mode, lot_size)
        if i == len(normalized_weights) - 1:
            allocated_so_far = sum(p["units"] for p in sell_plan)
            remaining = total_core_units - allocated_so_far
            sell_units = normalize_position_amount(remaining, mode, lot_size) if remaining > POSITION_EPSILON else 0.0
        if sell_units > POSITION_EPSILON:
            sell_plan.append({
                "step": i + 1,
                "units": sell_units,
                "weight_percent": round(pyramid_weights[i] * 100, 1),
            })
    return sell_plan


def get_core_sell_target_step(price, ma150, cfg, total_steps):
    if ma150 <= 0 or total_steps <= 0:
        return 0
    start_multiple = get_core_sell_start_multiple(cfg)
    current_multiple = price / ma150
    if current_multiple < start_multiple:
        return 0
    step_pct = get_core_sell_step_percent(cfg)
    step = int((current_multiple - start_multiple) / step_pct) + 1
    return min(max(step, 0), total_steps)


def get_zone(price_adj, ma150, ma300, cfg):
    box_upper_multiple = get_box_upper_multiple(cfg)
    if price_adj <= ma300:
        return "BELOW_MA300"
    if ma300 < price_adj < ma150:
        return "BETWEEN_300_150"
    if ma150 <= price_adj < ma150 * box_upper_multiple:
        return "BOX_AREA"
    return "ABOVE_120"


# ===========================
# 倒金字塔加仓计划
# ===========================
def calculate_pyramid_additions(cfg, current_units, target_units, double_target, lot_size=100):
    pyramid_weights = cfg.get(
        "pyramid_weights",
        [0.03, 0.055, 0.08, 0.105, 0.13, 0.155, 0.18, 0.205, 0.23, 0.255]
    )
    mode = get_position_mode(cfg)
    total_add_units = max(double_target - current_units, 0.0)
    if total_add_units <= POSITION_EPSILON:
        return []

    weight_sum = sum(pyramid_weights)
    normalized_weights = [w / weight_sum for w in pyramid_weights]

    add_plan = []
    for i, w in enumerate(normalized_weights):
        add_units = normalize_position_amount(total_add_units * w, mode, lot_size)

        if i == len(normalized_weights) - 1:
            allocated_so_far = sum(p["units"] for p in add_plan)
            remaining = total_add_units - allocated_so_far
            add_units = normalize_position_amount(remaining, mode, lot_size) if remaining > POSITION_EPSILON else 0.0

        if add_units > POSITION_EPSILON:
            add_plan.append({
                "step": i + 1,
                "units": add_units,
                "weight_percent": round(pyramid_weights[i] * 100, 1),
            })
    return add_plan


# ===========================
# 市场数据：统一获取 raw/adj/div/split
# ===========================
def fetch_market_data(symbol: str, days: int) -> pd.DataFrame:
    """
    返回 columns:
      date, raw_close, adj_close, dividend, split_ratio
    说明：
      - raw_close 用于成交 / 估值
      - adj_close 用于 MA / signal
      - dividend 为每股现金分红
      - split_ratio 为拆股比例（2.0 表示 1拆2；0.5 表示 2合1）
    """
    yahoo_symbol = to_yahoo_symbol(symbol)

    end_dt = datetime.now()
    start_dt = end_dt - timedelta(days=max(days * 3, 1200))

    ticker = yf.Ticker(yahoo_symbol)
    hist = ticker.history(
        start=start_dt.strftime("%Y-%m-%d"),
        end=(end_dt + timedelta(days=1)).strftime("%Y-%m-%d"),
        interval="1d",
        auto_adjust=False,
        actions=True,
        repair=True,
    )

    if hist is None or hist.empty:
        raise RuntimeError(f"无法拉取历史数据: {symbol} -> {yahoo_symbol}")

    hist = hist.copy().reset_index()
    date_col = "Date" if "Date" in hist.columns else hist.columns[0]
    hist["date"] = pd.to_datetime(hist[date_col]).dt.strftime("%Y-%m-%d")

    if "Close" not in hist.columns:
        raise RuntimeError(f"{symbol} 缺少 Close 列")
    if "Adj Close" not in hist.columns:
        hist["Adj Close"] = hist["Close"]
    if "Dividends" not in hist.columns:
        hist["Dividends"] = 0.0
    if "Stock Splits" not in hist.columns:
        hist["Stock Splits"] = 0.0

    out = hist[["date", "Close", "Adj Close", "Dividends", "Stock Splits"]].copy()
    out = out.rename(columns={
        "Close": "raw_close",
        "Adj Close": "adj_close",
        "Dividends": "dividend",
        "Stock Splits": "split_ratio",
    })

    out["raw_close"] = pd.to_numeric(out["raw_close"], errors="coerce")
    out["adj_close"] = pd.to_numeric(out["adj_close"], errors="coerce")
    out["dividend"] = pd.to_numeric(out["dividend"], errors="coerce").fillna(0.0)
    out["split_ratio"] = pd.to_numeric(out["split_ratio"], errors="coerce").fillna(0.0)

    out = out.dropna(subset=["raw_close", "adj_close"]).copy()
    out = out[out["raw_close"] > 0].copy()
    out = out[out["adj_close"] > 0].copy()
    out["split_ratio"] = out["split_ratio"].apply(lambda x: x if x and x > 0 else 1.0)
    out = out.tail(days).reset_index(drop=True)

    if len(out) < 10:
        raise RuntimeError(f"历史数据太少：{symbol} 仅 {len(out)} 条")

    return out


# ===========================
# 回测主逻辑
# ===========================
def backtest(symbol: str, name: str, cfg: dict, strategy: dict, days: int, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)

    log_path = outdir / f"backtest_{symbol}.log"
    logger = logging.getLogger(f"bt_{symbol}")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    fh = logging.FileHandler(str(log_path), encoding="utf-8", mode="w")
    fh.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(fh)

    df = fetch_market_data(symbol, days)
    dates = df["date"].tolist()
    raw_all = df["raw_close"].tolist()
    adj_all = df["adj_close"].tolist()
    div_all = df["dividend"].tolist()
    split_all = df["split_ratio"].tolist()

    ma_short_len = int(strategy.get("ma_period_short", 150))
    ma_long_len = int(strategy.get("ma_period_long", 300))

    position_mode = get_position_mode(cfg)
    target_units = get_target_units(cfg)
    base_units = get_base_units(cfg)
    double_target = get_double_target(cfg)

    fee_rate = _safe_float(cfg.get("fee_rate", 0.0), 0.0)
    slippage_bp = _safe_float(cfg.get("slippage_bp", 0.0), 0.0)
    initial_cash = _safe_float(cfg.get("initial_cash", 0.0), 0.0)
    lot_size = int(_safe_float(cfg.get("lot_size", 100), 100))

    if position_mode == "percent":
        cash = initial_cash if 0.0 < initial_cash <= 1.0 else max(1.0 - base_units, 0.0)
    else:
        cash = initial_cash

    units = normalize_position_amount(base_units, position_mode, lot_size)
    avg_cost = _safe_float(cfg.get("init_avg_cost", raw_all[0]), raw_all[0]) if units > POSITION_EPSILON else 0.0
    last_trade_price = raw_all[0]
    last_trade_side = "buy"
    pyramid_step = 0
    core_sell_step = 0
    realized_pnl = 0.0

    trades_csv = outdir / f"trades_{symbol}.csv"
    with open(trades_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow([
            "date", "symbol", "name",
            "action", "price", "qty", "qty_display", "fee",
            "cash_after", "pos_after", "avg_cost_after",
            "zone", "reason",
            "raw_close", "adj_close",
            "ma150", "ma300",
            "dividend", "split_ratio",
            "position_mode",
        ])

    actions_csv = outdir / f"actions_{symbol}.csv"
    with open(actions_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow([
            "date", "symbol", "name",
            "event_type", "value",
            "units_before", "units_after",
            "cash_before", "cash_after",
            "avg_cost_before", "avg_cost_after",
            "raw_close", "adj_close",
            "position_mode",
        ])

    def _append_trade_row(dt, action, px, qty, fee, zone, reason, raw_close, adj_close,
                          ma150_val, ma300_val, dividend, split_ratio, qty_display=None):
        with open(trades_csv, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow([
                dt, symbol, name,
                action, f"{px:.4f}", serialize_numeric(qty), qty_display or format_units_for_display(qty, position_mode), serialize_numeric(fee),
                serialize_numeric(cash), serialize_numeric(units), f"{avg_cost:.4f}" if avg_cost > 0 else "0",
                zone, reason,
                f"{raw_close:.4f}", f"{adj_close:.4f}",
                f"{ma150_val:.4f}" if ma150_val is not None else "",
                f"{ma300_val:.4f}" if ma300_val is not None else "",
                f"{dividend:.6f}" if dividend else "0",
                f"{split_ratio:.6f}" if split_ratio and split_ratio != 1.0 else "1.0",
                position_mode,
            ])

    def _append_action_row(dt, event_type, value, units_before, units_after,
                           cash_before, cash_after, avg_cost_before, avg_cost_after,
                           raw_close, adj_close):
        with open(actions_csv, "a", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow([
                dt, symbol, name,
                event_type, serialize_numeric(value),
                serialize_numeric(units_before), serialize_numeric(units_after),
                serialize_numeric(cash_before), serialize_numeric(cash_after),
                serialize_numeric(avg_cost_before), serialize_numeric(avg_cost_after),
                f"{raw_close:.4f}", f"{adj_close:.4f}",
                position_mode,
            ])

    def _exec_buy(dt, trade_price, qty, zone, reason, raw_close, adj_close,
                  ma150_val, ma300_val, dividend, split_ratio, qty_display=None):
        nonlocal cash, units, avg_cost, last_trade_price, last_trade_side, first_trade_date, first_trade_raw_price, first_trade_adj_price
        qty = normalize_position_amount(qty, position_mode, lot_size)
        if qty <= POSITION_EPSILON:
            return

        px = trade_price * (1.0 + slippage_bp / 10000.0)
        fee = (px * qty * fee_rate) if position_mode == "absolute" else (qty * fee_rate)
        cash -= (px * qty + fee) if position_mode == "absolute" else (qty + fee)

        avg_cost = calculate_new_avg_cost(units, avg_cost, qty, px)
        if first_trade_date is None:
            first_trade_date = dt
            first_trade_raw_price = raw_close
            first_trade_adj_price = adj_close
        units = normalize_position_amount(units + qty, position_mode, lot_size)
        last_trade_price = px
        last_trade_side = "buy"

        _append_trade_row(
            dt, "BUY", px, qty, fee, zone, reason, raw_close, adj_close,
            ma150_val, ma300_val, dividend, split_ratio, qty_display=qty_display
        )
        logger.info(
            f"[{dt}] BUY  {qty_display or format_units_for_display(qty, position_mode):<8} @ {px:.4f} | "
            f"fee={serialize_numeric(fee)} | cash={serialize_numeric(cash)} | pos={format_units_for_display(units, position_mode)} | "
            f"{zone} | {reason} | raw={raw_close:.4f} adj={adj_close:.4f} | "
            f"MA150={ma150_val:.4f} MA300={ma300_val:.4f}"
        )

    def _exec_sell(dt, trade_price, qty, zone, reason, raw_close, adj_close,
                   ma150_val, ma300_val, dividend, split_ratio, qty_display=None):
        nonlocal cash, units, avg_cost, last_trade_price, last_trade_side, realized_pnl, first_trade_date, first_trade_raw_price, first_trade_adj_price
        if units <= POSITION_EPSILON:
            return

        qty = min(_safe_float(qty, 0.0), units)
        qty = normalize_position_amount(qty, position_mode, lot_size)
        qty = min(qty, units)
        if qty <= POSITION_EPSILON:
            return

        px = trade_price * (1.0 - slippage_bp / 10000.0)
        avg_cost_before = avg_cost
        if first_trade_date is None:
            first_trade_date = dt
            first_trade_raw_price = raw_close
            first_trade_adj_price = adj_close

        if position_mode == "absolute":
            fee = px * qty * fee_rate
            cash += (px * qty - fee)
            if avg_cost_before > 0:
                realized_pnl += (px - avg_cost_before) * qty
        else:
            sale_value = qty * (px / avg_cost_before) if avg_cost_before > 0 else qty
            fee = sale_value * fee_rate
            cash += (sale_value - fee)
            if avg_cost_before > 0:
                realized_pnl += qty * (px / avg_cost_before - 1.0)

        units = normalize_position_amount(max(units - qty, 0.0), position_mode, lot_size)
        if units <= POSITION_EPSILON:
            units = 0.0
            avg_cost = 0.0

        last_trade_price = px
        last_trade_side = "sell"

        _append_trade_row(
            dt, "SELL", px, qty, fee, zone, reason, raw_close, adj_close,
            ma150_val, ma300_val, dividend, split_ratio, qty_display=qty_display
        )
        logger.info(
            f"[{dt}] SELL {qty_display or format_units_for_display(qty, position_mode):<8} @ {px:.4f} | "
            f"fee={serialize_numeric(fee)} | cash={serialize_numeric(cash)} | pos={format_units_for_display(units, position_mode)} | "
            f"{zone} | {reason} | raw={raw_close:.4f} adj={adj_close:.4f} | "
            f"MA150={ma150_val:.4f} MA300={ma300_val:.4f}"
        )

    start_value = get_total_value(cash, units, avg_cost, raw_all[0], position_mode)
    if start_value <= POSITION_EPSILON:
        start_value = 1.0

    peak_value = None
    max_dd_ref = 0.0
    start_raw_price = raw_all[0]
    start_adj_price = adj_all[0]
    first_trade_date = None
    first_trade_raw_price = None
    first_trade_adj_price = None

    logger.info("=" * 80)
    logger.info(f"Backtest start: {symbol} ({name})")
    logger.info(
        f"mode={position_mode} | Bars={len(df)} | base={format_units_for_display(base_units, position_mode)} | "
        f"target={format_units_for_display(target_units, position_mode)} | upper={format_units_for_display(double_target, position_mode)} | "
        f"box_upper=MA150*{get_box_upper_multiple(cfg):.2f} | core_sell=MA150*{get_core_sell_start_multiple(cfg):.2f} "
        f"step={format_percent_ratio(get_core_sell_step_percent(cfg))}"
    )
    if position_mode == "absolute":
        logger.info(f"initial_cash={cash:.2f} | fee_rate={fee_rate} | slippage_bp={slippage_bp} | lot_size={lot_size}")
    else:
        logger.info(f"initial_cash_weight={format_percent_ratio(cash)} | fee_rate={fee_rate} | slippage_bp={slippage_bp}")
    logger.info("MODE: 信号=Adj Close；成交/估值=Close；事件=Dividends + Stock Splits")
    logger.info("=" * 80)

    for i in range(len(df)):
        dt = dates[i]
        raw_price = float(raw_all[i])
        adj_price = float(adj_all[i])
        dividend = float(div_all[i] or 0.0)
        split_ratio = float(split_all[i] or 1.0)

        if split_ratio != 1.0 and units > POSITION_EPSILON:
            units_before = units
            cash_before = cash
            avg_cost_before = avg_cost

            if position_mode == "absolute":
                units = int(round(units * split_ratio))
            else:
                units = units
            if avg_cost > 0:
                avg_cost = avg_cost / split_ratio

            _append_action_row(
                dt, "SPLIT", split_ratio,
                units_before, units,
                cash_before, cash,
                avg_cost_before, avg_cost,
                raw_price, adj_price,
            )
            logger.info(
                f"[{dt}] ACTION SPLIT ratio={split_ratio:.6f} | units {format_units_for_display(units_before, position_mode)} -> {format_units_for_display(units, position_mode)} | "
                f"avg_cost {avg_cost_before:.6f} -> {avg_cost:.6f}"
            )

        if dividend > 0 and units > POSITION_EPSILON:
            units_before = units
            cash_before = cash
            avg_cost_before = avg_cost

            if position_mode == "absolute":
                cash += units * dividend
                dividend_value = units * dividend
            else:
                dividend_value = units * dividend / avg_cost if avg_cost > 0 else 0.0
                cash += dividend_value

            _append_action_row(
                dt, "DIVIDEND", dividend_value,
                units_before, units,
                cash_before, cash,
                avg_cost_before, avg_cost,
                raw_price, adj_price,
            )
            logger.info(
                f"[{dt}] ACTION DIVIDEND value={serialize_numeric(dividend_value)} | units={format_units_for_display(units, position_mode)} | "
                f"cash {serialize_numeric(cash_before)} -> {serialize_numeric(cash)}"
            )

        closes_adj = adj_all[: i + 1]

        ma150_raw, _src150 = calc_ma_with_coef(closes_adj, ma_short_len)
        if ma150_raw is None:
            cur_value = get_total_value(cash, units, avg_cost, raw_price, position_mode)
            if peak_value is None or cur_value > peak_value:
                peak_value = cur_value
            if peak_value and peak_value > 0:
                max_dd_ref = max(max_dd_ref, (peak_value - cur_value) / peak_value)
            continue

        sideways_score = float(compute_sideways_index(closes_adj, cfg))
        base_k150 = _safe_float(cfg.get("k150", 1.0), 1.0)
        min_k150 = _safe_float(cfg.get("sideways_min_k150", 0.85), 0.85)
        if base_k150 < min_k150:
            min_k150 = base_k150
        dynamic_k150 = min_k150 + (base_k150 - min_k150) * (1.0 - sideways_score)
        ma150 = ma150_raw * dynamic_k150

        ma300_min_coef = _safe_float(cfg.get("ma300_min_coef", 0.85), 0.85)
        ma300_raw, _ = calc_ma_with_coef(closes_adj, ma_long_len)
        if ma300_raw is not None:
            base_k300 = _safe_float(cfg.get("k300", 1.0), 1.0)
            ma300_coef = ma300_raw * base_k300
            ma300_alt = ma150 * ma300_min_coef
            ma300 = min(ma300_coef, ma300_alt)
        else:
            ma300 = ma150 * ma300_min_coef

        zone = get_zone(adj_price, ma150, ma300, cfg)

        if zone == "BELOW_MA300":
            pass

        elif zone == "BETWEEN_300_150":
            price_diff = ma150 - ma300
            if price_diff > 0 and double_target - units > POSITION_EPSILON:
                position_ratio = (ma150 - adj_price) / price_diff
                position_ratio = max(0.0, min(1.0, position_ratio))

                total_steps = int(cfg.get("pyramid_steps", 10))
                target_step = int(position_ratio * total_steps) + 1
                target_step = min(target_step, total_steps)

                if target_step > pyramid_step:
                    add_plan = calculate_pyramid_additions(cfg, units, target_units, double_target, lot_size)
                    for step_info in add_plan[pyramid_step:target_step]:
                        add_units = step_info["units"]
                        max_add = normalize_position_amount(double_target - units, position_mode, lot_size)
                        add_units = normalize_position_amount(min(add_units, max_add), position_mode, lot_size)
                        if add_units > POSITION_EPSILON:
                            _exec_buy(
                                dt, raw_price, add_units, zone, f"PYRAMID_STEP_{step_info['step']}",
                                raw_price, adj_price, ma150, ma300, dividend, split_ratio,
                                qty_display=format_units_for_display(add_units, position_mode),
                            )
                            pyramid_step = step_info["step"]
                            if units >= target_units - POSITION_EPSILON and raw_price < ma150 * get_core_sell_start_multiple(cfg):
                                core_sell_step = 0

        elif zone == "BOX_AREA":
            target_gap = normalize_position_amount(max(target_units - units, 0.0), position_mode, lot_size)
            if target_gap > POSITION_EPSILON:
                _exec_buy(
                    dt, raw_price, target_gap, zone, "BOX_CORE_BUILD",
                    raw_price, adj_price, ma150, ma300, dividend, split_ratio,
                    qty_display=format_units_for_display(target_gap, position_mode),
                )
                core_sell_step = 0
            elif get_box_grid_enabled(cfg):
                grid_pct = _safe_float(cfg.get("grid_box_percent", 0.01), 0.01)
                if grid_pct <= 0:
                    grid_pct = 0.01
                if last_trade_price <= 0:
                    last_trade_price = raw_price
                grid_step = max(last_trade_price * grid_pct, 1e-6)
                last_grid = math.floor((last_trade_price - ma150) / grid_step)
                current_grid = math.floor((raw_price - ma150) / grid_step)
                min_change = last_trade_price * grid_pct
                if current_grid > last_grid and abs(raw_price - last_trade_price) >= min_change:
                    requested_units = get_step_trade_units(cfg, "grid_box_units_percent", 1, lot_size)
                    sellable = normalize_position_amount(max(units - target_units, 0.0), position_mode, lot_size)
                    sell_units = normalize_position_amount(min(requested_units, sellable), position_mode, lot_size)
                    if sell_units > POSITION_EPSILON:
                        qty_display = get_step_trade_display(cfg, "grid_box_units_percent") if abs(sell_units - requested_units) <= POSITION_EPSILON else format_units_for_display(sell_units, position_mode)
                        _exec_sell(
                            dt, raw_price, sell_units, zone, "BOX_GRID_SELL",
                            raw_price, adj_price, ma150, ma300, dividend, split_ratio,
                            qty_display=qty_display,
                        )
                elif current_grid < last_grid and abs(raw_price - last_trade_price) >= min_change:
                    requested_units = get_step_trade_units(cfg, "grid_box_units_percent", 1, lot_size)
                    buyable = normalize_position_amount(max(double_target - units, 0.0), position_mode, lot_size)
                    buy_units = normalize_position_amount(min(requested_units, buyable), position_mode, lot_size)
                    if buy_units > POSITION_EPSILON:
                        qty_display = get_step_trade_display(cfg, "grid_box_units_percent") if abs(buy_units - requested_units) <= POSITION_EPSILON else format_units_for_display(buy_units, position_mode)
                        _exec_buy(
                            dt, raw_price, buy_units, zone, "BOX_GRID_BUY",
                            raw_price, adj_price, ma150, ma300, dividend, split_ratio,
                            qty_display=qty_display,
                        )

        else:
            sell_up_pct = _safe_float(cfg.get("sell_trigger_up_percent", 0.01), 0.01)
            if sell_up_pct <= 0:
                sell_up_pct = 0.01
            if last_trade_price <= 0:
                last_trade_price = raw_price

            sell_step = last_trade_price * sell_up_pct
            if sell_step <= 0:
                sell_step = raw_price * sell_up_pct

            last_step = math.floor((last_trade_price - ma150) / sell_step)
            now_step = math.floor((raw_price - ma150) / sell_step)
            min_change = last_trade_price * sell_up_pct
            core_sell_start_price = ma150 * get_core_sell_start_multiple(cfg)
            core_sell_plan = calculate_core_sell_plan(cfg, target_units, lot_size)
            target_core_step = get_core_sell_target_step(raw_price, ma150, cfg, len(core_sell_plan))

            if now_step > last_step and abs(raw_price - last_trade_price) >= min_change:
                step_diff = now_step - last_step
                requested_sell_units = get_step_trade_units(cfg, "sell_percent", step_diff, lot_size)
                excess_units = normalize_position_amount(max(units - target_units, 0.0), position_mode, lot_size)
                sell_units = normalize_position_amount(min(requested_sell_units, excess_units), position_mode, lot_size)
                if sell_units > POSITION_EPSILON:
                    qty_display = format_units_for_display(sell_units, position_mode)
                    _exec_sell(
                        dt, raw_price, sell_units, zone, "ABOVE_120_EXCESS_SELL",
                        raw_price, adj_price, ma150, ma300, dividend, split_ratio,
                        qty_display=qty_display,
                    )

            if target_core_step > core_sell_step:
                for step_info in core_sell_plan[core_sell_step:target_core_step]:
                    current_core_units = normalize_position_amount(min(units, target_units), position_mode, lot_size)
                    sell_units = normalize_position_amount(min(step_info["units"], current_core_units), position_mode, lot_size)
                    if sell_units > POSITION_EPSILON:
                        _exec_sell(
                            dt, raw_price, sell_units, zone, f"ABOVE_120_CORE_PYRAMID_SELL_STEP_{step_info['step']}",
                            raw_price, adj_price, ma150, ma300, dividend, split_ratio,
                            qty_display=format_units_for_display(sell_units, position_mode),
                        )
                    core_sell_step = step_info["step"]

        cur_value = get_total_value(cash, units, avg_cost, raw_price, position_mode)
        if peak_value is None or cur_value > peak_value:
            peak_value = cur_value
        if peak_value and peak_value > 0:
            max_dd_ref = max(max_dd_ref, (peak_value - cur_value) / peak_value)

    end_value = get_total_value(cash, units, avg_cost, raw_all[-1], position_mode)
    final_market_weight = get_market_weight(units, avg_cost, raw_all[-1], position_mode)
    floating_pnl = (raw_all[-1] - avg_cost) * units if position_mode == "absolute" and units > POSITION_EPSILON and avg_cost > 0 else 0.0
    if position_mode == "percent" and units > POSITION_EPSILON and avg_cost > 0:
        floating_pnl = units * (raw_all[-1] / avg_cost - 1.0)
    holding_stock_return = (raw_all[-1] / avg_cost - 1.0) if units > POSITION_EPSILON and avg_cost > 0 else 0.0

    total_fee = 0.0
    buy_cnt = 0
    sell_cnt = 0
    with open(trades_csv, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row["action"] == "BUY":
                buy_cnt += 1
            elif row["action"] == "SELL":
                sell_cnt += 1
            try:
                total_fee += float(row["fee"])
            except Exception:
                pass

    dividend_events = 0
    split_events = 0
    with open(actions_csv, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row["event_type"] == "DIVIDEND":
                dividend_events += 1
            elif row["event_type"] == "SPLIT":
                split_events += 1

    summary = {
        "symbol": symbol,
        "name": name,
        "position_mode": position_mode,
        "bars": len(df),
        "start_value": start_value,
        "end_value": end_value,
        "realized_pnl": realized_pnl,
        "floating_pnl": floating_pnl,
        "holding_stock_return": holding_stock_return,
        "total_return": (end_value / start_value - 1.0) if start_value > 0 else 0.0,
        "max_drawdown_ref": max_dd_ref,
        "buy_trades": buy_cnt,
        "sell_trades": sell_cnt,
        "dividend_events": dividend_events,
        "split_events": split_events,
        "total_fee": total_fee,
        "final_cash": cash,
        "final_units": units,
        "final_market_weight": final_market_weight,
        "start_raw_price": start_raw_price,
        "start_adj_price": start_adj_price,
        "first_trade_date": first_trade_date,
        "first_trade_raw_price": first_trade_raw_price,
        "first_trade_adj_price": first_trade_adj_price,
        "last_raw_price": raw_all[-1],
        "last_adj_price": adj_all[-1],
        "log_path": str(log_path),
        "trades_csv": str(trades_csv),
        "actions_csv": str(actions_csv),
    }

    summary_path = outdir / f"summary_{symbol}.json"
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    logger.info("=" * 80)
    logger.info("SUMMARY")
    logger.info(json.dumps(summary, ensure_ascii=False, indent=2))
    logger.info("=" * 80)

    return summary


# ===========================
# 从 dcf.yaml 中按 symbol 找配置
# ===========================


def derive_target_from_base(base):
    if isinstance(base, str) and base.strip().endswith("%"):
        pct = float(base.strip()[:-1])
        return f"{pct * 2:.6f}%"
    return str(parse_position_value(base) * 2.0)

def find_cfg_by_symbol(etf_config: dict, symbol: str):
    symbol = symbol.upper().strip()
    for name, cfg in etf_config.items():
        if str(cfg.get("symbol", "")).upper().strip() == symbol:
            return name, cfg
    return None, None


def resolve_backtest_cfg(symbol: str, etf_config: dict, common_cfg: dict):
    name, cfg = find_cfg_by_symbol(etf_config, symbol)
    if cfg is not None:
        resolved = dict(common_cfg or {})
        resolved.update(dict(cfg))
        return name, resolved, False

    if common_cfg:
        resolved = dict(common_cfg)
        resolved["symbol"] = symbol
        resolved.setdefault("strategy_run", "no")
        name = str(common_cfg.get("name", "通用回测参数"))
        return name, resolved, True

    return None, None, False


# ===========================
# CLI入口
# ===========================
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="dcf.yaml", help="path to dcf.yaml")
    ap.add_argument("--symbol", required=True, help="SH600519 / SZ000001 / HK00700")
    ap.add_argument("--days", type=int, default=800, help="history length")
    ap.add_argument("--outdir", default="backtest_out", help="output directory")
    ap.add_argument("--base-units", default=None, help="覆盖配置中的初始仓位，如 2.5%")
    ap.add_argument("--target-units", default=None, help="覆盖配置中的目标仓位，如 5%")
    ap.add_argument("--double-target-factor", type=float, default=None, help="覆盖最大仓位倍数")
    args = ap.parse_args()

    base_dir = Path(__file__).resolve().parent
    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = base_dir / args.config

    etf_cfg, strategy_cfg, common_cfg = load_config(str(config_path))
    symbol = args.symbol.upper().strip()

    name, cfg, used_common_cfg = resolve_backtest_cfg(symbol, etf_cfg, common_cfg)
    if cfg is None:
        raise SystemExit(
            f"❌ dcf.yaml 中既找不到 symbol={symbol} 的 ETF_CONFIG 专属配置，也没有 COMMON_BACKTEST_CONFIG 通用配置。\n"
            f"请先在 dcf.yaml 中补充该标的配置，或添加 COMMON_BACKTEST_CONFIG。"
        )

    cfg = dict(cfg)
    if args.base_units is not None:
        cfg["base_units"] = args.base_units.strip()
        if args.target_units is None:
            cfg["target_units"] = derive_target_from_base(cfg["base_units"])

    if args.target_units is not None:
        cfg["target_units"] = args.target_units.strip()

    if args.double_target_factor is not None:
        cfg["double_target_factor"] = args.double_target_factor

    outdir = base_dir / args.outdir / symbol
    summary = backtest(symbol=symbol, name=name, cfg=cfg, strategy=strategy_cfg, days=args.days, outdir=outdir)

    print("\n================ 回测结果 ================\n")
    if used_common_cfg:
        print(f"提示: {symbol} 未在 ETF_CONFIG 中配置，已自动回退到 COMMON_BACKTEST_CONFIG 通用参数。")
    print(f"标的: {summary['symbol']} | 名称: {summary['name']}")
    print(f"模式: {'百分比仓位' if summary['position_mode'] == 'percent' else '股数仓位'}")
    print(f"K线数量: {summary['bars']}")
    print(f"买入次数: {summary['buy_trades']}")
    print(f"卖出次数: {summary['sell_trades']}")
    print(f"分红事件: {summary['dividend_events']}")
    print(f"拆股事件: {summary['split_events']}")
    print(f"最大回撤(参考): {summary['max_drawdown_ref'] * 100:.2f}%")
    print(f"总手续费: {serialize_numeric(summary['total_fee'])}")

    if summary['position_mode'] == 'absolute':
        print(f"起始价值(参考): {summary['start_value']:.2f}")
        print(f"结束价值(参考): {summary['end_value']:.2f}")
        print(f"已实现收益(参考): {summary['realized_pnl']:.2f}")
        print(f"浮动盈亏(参考): {summary['floating_pnl']:.2f}")
        print(f"综合收益率(参考): {summary['total_return'] * 100:.2f}%")
        print(f"个股收益(持仓部分): {summary['holding_stock_return'] * 100:.2f}%")
        print(f"期末现金: {summary['final_cash']:.2f}")
        print(f"期末持仓: {format_units_for_display(summary['final_units'], 'absolute')}")
        print(f"期末持仓市值: {summary['final_market_weight']:.2f}")
    else:
        print(f"起始总权益(参考): {format_percent_ratio(summary['start_value'])}")
        print(f"结束总权益(参考): {format_percent_ratio(summary['end_value'])}")
        print(f"已实现收益贡献(参考): {format_percent_ratio(summary['realized_pnl'])}")
        print(f"浮动收益贡献(参考): {format_percent_ratio(summary['floating_pnl'])}")
        print(f"综合收益率(参考): {summary['total_return'] * 100:.2f}%")
        print(f"个股收益(持仓部分): {summary['holding_stock_return'] * 100:.2f}%")
        print(f"期末现金权重: {format_percent_ratio(summary['final_cash'])}")
        print(f"期末持仓(成本口径): {format_units_for_display(summary['final_units'], 'percent')}")
        print(f"期末估算市值权重: {format_percent_ratio(summary['final_market_weight'])}")

    print(f"起始原始价: {summary['start_raw_price']:.4f}")
    print(f"起始复权价: {summary['start_adj_price']:.4f}")
    if summary.get('first_trade_date'):
        print(f"首次建仓日: {summary['first_trade_date']}")
        print(f"首次建仓原始价: {summary['first_trade_raw_price']:.4f}")
        print(f"首次建仓复权价: {summary['first_trade_adj_price']:.4f}")
    print(f"最新原始价: {summary['last_raw_price']:.4f}")
    print(f"最新复权价: {summary['last_adj_price']:.4f}")
    print(f"\n日志: {summary['log_path']}")
    print(f"交易明细: {summary['trades_csv']}")
    print(f"事件明细: {summary['actions_csv']}")
    print("\n说明：")
    print("1) 信号使用 Adj Close；成交/估值使用 Close；")
    print("2) 分红按除息日入账；拆股按除权日调整成本；")
    print("3) 若 symbol 不在 ETF_CONFIG 中，会自动使用 COMMON_BACKTEST_CONFIG 的通用参数；")
    print("4) --base-units 可覆盖配置中的初始仓位；若未给 --target-units，则默认自动取 base 的 2 倍；")
    print("5) BOX_AREA 会优先把仓位补足到目标仓位；若 box_grid_enabled=yes，目标仓位建立后按箱体网格交易；否则默认不买不卖；")
    print("6) ABOVE_120 在 MA150*core_sell_start_multiple 之前，只卖超过目标仓位的机动仓；")
    print("7) 达到 MA150*core_sell_start_multiple 后，底仓按正金字塔逐步卖出；")
    print("8) 百分比模式下，qty / pos_after 表示仓位比例（成本口径），不是股数；")
    print("9) 百分比模式下，已实现/浮动收益展示的是对总账户收益贡献的估算值；")
    print("10) trades_csv 已记录每笔成交时的 raw_close / adj_close / ma150 / ma300。")
    print("=========================================\n")


if __name__ == "__main__":
    main()

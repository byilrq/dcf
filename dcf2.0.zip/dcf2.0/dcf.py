import time as time_module
import json
from pathlib import Path
from datetime import datetime, time, timedelta
import requests
import logging
import os
import math
import csv
import shutil
import sys
import re
from datetime import datetime
# ===========================
# 路径配置
# ===========================
BASE_DIR = Path(__file__).parent
config_path = os.path.join(BASE_DIR, "dcf.yaml")
STATE_FILE = BASE_DIR / "dcf_monitor_state.json"
LOG_DIR = BASE_DIR / "log"
TRADE_LOG_FILE = BASE_DIR / "trade_log.csv"
LOG_DIR.mkdir(exist_ok=True)
# ===========================
# 辅助函数
# ===========================
def calculate_new_avg_cost(old_position, old_avg_cost, add_units, add_price):
    """计算加仓后的新平均成本"""
    if old_position == 0:
        return add_price
    total_cost_before = old_position * old_avg_cost
    total_cost_after = total_cost_before + add_units * add_price
    return total_cost_after / (old_position + add_units)
def _parse_hm(s: str):
    """把 '09:30' 解析成 (9, 30)"""
    try:
        h, m = s.split(":")
        return int(h), int(m)
    except Exception:
        return 9, 30
def round_to_lot(qty, lot_size=100):
    """将数量调整为交易单位的整倍数（A股标准为100股）"""
    if qty <= 0:
        return 0
    rounded_qty = int(qty // lot_size) * lot_size
    if rounded_qty == 0 and qty > 0:
        rounded_qty = lot_size
    return rounded_qty
POSITION_EPSILON = 1e-9
def _safe_float(value, default=0.0):
    try:
        if isinstance(value, str):
            value = value.strip()
            if not value:
                return default
        return float(value)
    except Exception:
        return default
def get_position_mode(cfg):
    base = cfg.get("base_units", 0)
    target = cfg.get("target_units", 0)
    if isinstance(base, str) and base.strip().endswith("%"):
        return "percent"
    if isinstance(target, str) and target.strip().endswith("%"):
        return "percent"
    try:
        base_f = float(base)
        target_f = float(target)
        if 0 <= base_f <= 1 and 0 <= target_f <= 1:
            return "percent"
    except Exception:
        pass
    return "absolute"
def parse_position_value(value, mode=None):
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return 0.0
        if s.endswith("%"):
            return float(s[:-1]) / 100.0
        return float(s)
    return _safe_float(value, 0.0)
def get_base_units(cfg):
    mode = get_position_mode(cfg)
    return parse_position_value(cfg.get("base_units", 0), mode)
def get_target_units(cfg):
    mode = get_position_mode(cfg)
    return parse_position_value(cfg.get("target_units", 0), mode)
def get_double_target(cfg):
    return get_target_units(cfg) * _safe_float(cfg.get("double_target_factor", 2.0), 2.0)
def get_live_current_units(cfg):
    if "current_units" not in cfg or cfg.get("current_units") in (None, ""):
        return None
    mode = get_position_mode(cfg)
    return normalize_position_amount(parse_position_value(cfg.get("current_units", 0), mode), mode)
def get_live_current_avg_cost(cfg):
    if "current_avg_cost" not in cfg or cfg.get("current_avg_cost") in (None, ""):
        return None
    return max(_safe_float(cfg.get("current_avg_cost", 0.0), 0.0), 0.0)
def normalize_position_amount(value, mode):
    value = max(_safe_float(value, 0.0), 0.0)
    if mode == "percent":
        if value <= POSITION_EPSILON:
            return 0.0
        return round(value, 6)
    return round_to_lot(value)
def format_percent_ratio(value, digits=2):
    pct = _safe_float(value, 0.0) * 100.0
    s = f"{pct:.{digits}f}".rstrip("0").rstrip(".")
    if s in {"", "-0"}:
        s = "0"
    return f"{s}%"
def format_units_for_display(value, mode):
    if mode == "percent":
        return format_percent_ratio(value)
    return f"{int(round(_safe_float(value, 0.0))):,}股"
def format_trade_rate_display(rate):
    return format_percent_ratio(rate)
def serialize_numeric(value, digits=6):
    if value is None or value == "":
        return ""
    if isinstance(value, str):
        return value
    s = f"{float(value):.{digits}f}".rstrip("0").rstrip(".")
    return s if s else "0"
def get_step_trade_units(cfg, pct_key, step_diff=1):
    mode = get_position_mode(cfg)
    pct = max(_safe_float(cfg.get(pct_key, 0.0), 0.0), 0.0)
    reference = get_base_units(cfg) if mode == "percent" else get_target_units(cfg)
    return normalize_position_amount(reference * pct * step_diff, mode)
def get_step_trade_display(cfg, pct_key, step_diff=1):
    pct = max(_safe_float(cfg.get(pct_key, 0.0), 0.0), 0.0)
    return format_trade_rate_display(pct * step_diff)
def build_default_symbol_state(cfg):
    base_units = get_base_units(cfg)
    live_units = get_live_current_units(cfg)
    live_avg_cost = get_live_current_avg_cost(cfg)
    return {
        "last_price": None,
        "last_trade_price": None,
        "last_trade_side": "buy",
        "tick": 0,
        "current_units": live_units if live_units is not None else base_units,
        "avg_cost": live_avg_cost if live_avg_cost is not None else 0.0,
        "ma_short": None,
        "ma_long": None,
        "ma_long_source": None,
        "last_status_msg": None,
        "pyramid_step": 0,
        "core_sell_step": 0,
        "pyramid_units": [],
        "strategy_run": cfg.get("strategy_run", "yes"),
        "position_mode": get_position_mode(cfg),
    }
def normalize_symbol_state(name, cfg, entry):
    mode = get_position_mode(cfg)
    base_units = get_base_units(cfg)
    live_units = get_live_current_units(cfg)
    live_avg_cost = get_live_current_avg_cost(cfg)
    double_target = get_double_target(cfg)
    legacy_mode = entry.get("position_mode")
    reset_reason = None
    if "last_trade_price" not in entry:
        entry["last_trade_price"] = None
    if "last_trade_side" not in entry:
        entry["last_trade_side"] = "buy"
    if "avg_cost" not in entry:
        entry["avg_cost"] = 0.0
    if "strategy_run" not in entry:
        entry["strategy_run"] = cfg.get("strategy_run", "yes")
    if "pyramid_step" not in entry:
        entry["pyramid_step"] = 0
    if "core_sell_step" not in entry:
        entry["core_sell_step"] = 0
    if "pyramid_units" not in entry or not isinstance(entry.get("pyramid_units"), list):
        entry["pyramid_units"] = []
    current_units = entry.get("current_units", live_units if live_units is not None else base_units)
    try:
        current_units = float(current_units)
    except Exception:
        reset_reason = "current_units 无法解析"
        current_units = base_units
    if legacy_mode and legacy_mode != mode:
        reset_reason = f"状态文件仓位模式为 {legacy_mode}，当前配置为 {mode}"
    if mode == "percent":
        if current_units < -POSITION_EPSILON:
            reset_reason = "current_units 为负数"
        elif current_units > max(1.0, double_target * 5):
            reset_reason = "检测到旧版按股数状态，无法自动换算为百分比仓位"
    else:
        if current_units < 0:
            reset_reason = "current_units 为负数"
    if reset_reason:
        logging.warning(
            f"⚠️ {name}: {reset_reason}，已重置为基准仓位 {format_units_for_display(live_units if live_units is not None else base_units, mode)}"
        )
        entry["current_units"] = live_units if live_units is not None else base_units
        entry["avg_cost"] = live_avg_cost if live_avg_cost is not None else 0.0
        entry["pyramid_step"] = 0
        entry["core_sell_step"] = 0
        entry["pyramid_units"] = []
    else:
        entry["current_units"] = normalize_position_amount(current_units, mode)
        if live_units is not None:
            entry["current_units"] = live_units
        if live_avg_cost is not None:
            entry["avg_cost"] = live_avg_cost
        elif entry["current_units"] <= POSITION_EPSILON:
            entry["avg_cost"] = 0.0
    entry["position_mode"] = mode
    return entry
# ===========================
# 日志轮转与备份函数
# ===========================
def rotate_and_backup_logs(now: datetime = None):
    if now is None:
        now = datetime.now()
    
    log_file = BASE_DIR / "dcf.log"  # 正确的日志文件路径
    # 这里用昨天的日期作为备份名
    backup_date = (now.date() - timedelta(days=1))
    # 修改备份文件名格式：dcf.YYYYMMDD.log
    backup_file = LOG_DIR / f"dcf.{backup_date.strftime('%Y%m%d')}.log"
    
    if not log_file.exists():
        return False
    
    try:
        shutil.copy2(log_file, backup_file)
        logger = logging.getLogger()
        for handler in logger.handlers[:]:
            handler.close()
            logger.removeHandler(handler)
        
        # 清空当前日志文件
        with open(log_file, 'w', encoding='utf-8') as f:
            f.truncate(0)
        
        # 重新配置新的 handler
        setup_logging()
        
        logging.info("=" * 60)
        logging.info(f"🔄 日志轮转完成 - {now.strftime('%Y-%m-%d %H:%M:%S')}")
        logging.info(f"📁 日志已备份至: {backup_file.name}")
        logging.info("=" * 60)
        
        return True
    except Exception as e:
        print(f"日志轮转失败: {e}")
        setup_logging()
        return False
def setup_logging():
    """配置日志系统"""
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    if logger.hasHandlers():
        logger.handlers.clear()
    # 当前日志文件放在 BASE_DIR 根目录
    log_file = BASE_DIR / "dcf.log"
    file_handler = logging.FileHandler(
        filename=str(log_file),
        encoding="utf-8",
        mode='a'
    )
    file_handler.setLevel(logging.INFO)
    # 只输出消息本身
    formatter = logging.Formatter("%(message)s")
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger
logger = setup_logging()
# ===========================
# 读取配置文件
# ===========================
def load_config(path):
    try:
        import yaml
    except ImportError:
        import json5 as json_mod
        with open(path, "r", encoding="utf-8") as f:
            cfg = json_mod.load(f)
    else:
        with open(path, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f)
    cfg = cfg or {}
    dcf_cfg = cfg.get("ETF_CONFIG", {}) or {}
    strategy_cfg = cfg.get("STRATEGY", {}) or {}
    return dcf_cfg, strategy_cfg, cfg
def save_full_config(full_cfg, path=None):
    target = path or config_path
    try:
        import yaml
    except ImportError:
        return False
    with open(target, "w", encoding="utf-8") as f:
        yaml.safe_dump(full_cfg, f, allow_unicode=True, sort_keys=False)
    return True
def persist_runtime_position_to_config(name, current_units, avg_cost):
    global FULL_CONFIG, ETF_CONFIG
    if not isinstance(FULL_CONFIG, dict):
        return False
    etf_cfg = FULL_CONFIG.setdefault("ETF_CONFIG", {})
    if name not in etf_cfg or not isinstance(etf_cfg.get(name), dict):
        return False
    mode = get_position_mode(etf_cfg[name])
    etf_cfg[name]["current_units"] = format_units_for_display(current_units, mode) if mode == "percent" else int(round(_safe_float(current_units, 0.0)))
    etf_cfg[name]["current_avg_cost"] = round(_safe_float(avg_cost, 0.0), 6) if _safe_float(avg_cost, 0.0) > 0 else 0.0
    ETF_CONFIG[name]["current_units"] = etf_cfg[name]["current_units"]
    ETF_CONFIG[name]["current_avg_cost"] = etf_cfg[name]["current_avg_cost"]
    return save_full_config(FULL_CONFIG)
# 全局策略参数默认值（会被 dcf.yaml 覆盖）
FULL_CONFIG = {}
STRATEGY = {
    "loop_interval": 60,
    "fetch_history_days": 400,
    "ma_period_short": 150,
    "ma_period_long": 300,
    "session_start": "09:30",
    "session_end": "16:00",
    "daily_push_time": "09:00",
    "log_rotate_time": "09:00"
}
# ===========================
# 时间控制函数
# ===========================
def in_trade_session(now: datetime = None) -> bool:
    """是否在交易时段"""
    if now is None:
        now = datetime.now()
    start_str = STRATEGY.get("session_start", "09:30")
    end_str = STRATEGY.get("session_end", "16:00")
    sh, sm = _parse_hm(start_str)
    eh, em = _parse_hm(end_str)
    t = now.time()
    start_t = time(sh, sm)
    end_t = time(eh, em)
    return start_t <= t <= end_t
def should_rotate_logs(state: dict, now: datetime = None) -> bool:
    """是否需要执行日志轮转"""
    if now is None:
        now = datetime.now()
   
    rotate_str = STRATEGY.get("log_rotate_time", "09:00")
    rh, rm = _parse_hm(rotate_str)
    rotate_t = time(rh, rm)
   
    today = now.date().isoformat()
    meta = state.get("_meta", {})
    last_rotate_date = meta.get("last_log_rotate_date")
   
    if now.time() >= rotate_t and last_rotate_date != today:
        return True
    return False
def should_do_daily_push(state: dict, now: datetime = None) -> bool:
    """是否需要执行每日快照推送（目前在日志轮转时一起做）"""
    if now is None:
        now = datetime.now()
    push_str = STRATEGY.get("daily_push_time", "09:00")
    ph, pm = _parse_hm(push_str)
    push_t = time(ph, pm)
    today = now.date().isoformat()
    meta = state.get("_meta", {})
    last_date = meta.get("last_daily_push_date")
    if now.time() >= push_t and last_date != today:
        return True
    return False
# ===========================
# 状态文件读写
# ===========================
def load_state():
    """加载状态文件"""
    if STATE_FILE.exists():
        try:
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                state = json.load(f)
            for name, cfg in ETF_CONFIG.items():
                if name not in state or not isinstance(state.get(name), dict):
                    state[name] = build_default_symbol_state(cfg)
                else:
                    state[name] = normalize_symbol_state(name, cfg, state[name])
            if "_meta" not in state:
                state["_meta"] = {
                    "last_daily_push_date": None,
                    "last_log_rotate_date": None
                }
            elif "last_log_rotate_date" not in state["_meta"]:
                state["_meta"]["last_log_rotate_date"] = None
            return state
        except Exception as e:
            logging.error(f"加载状态文件失败: {e}")
            return {}
    initial_state = {}
    for name, cfg in ETF_CONFIG.items():
        initial_state[name] = build_default_symbol_state(cfg)
    initial_state["_meta"] = {
        "last_daily_push_date": None,
        "last_log_rotate_date": None
    }
    return initial_state
def save_state(state):
    """保存状态文件"""
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)
# ===========================
# 构建每日快照
# ===========================
def build_daily_snapshot(state: dict) -> str:
    """用 last_status_msg 构造每日快照文本"""
    import re
    lines = []
    current_time = datetime.now().strftime("%Y.%m.%d.%H:%M")
   
    for name in ETF_CONFIG.keys():
        dcf_state = state.get(name, {})
        status = dcf_state.get("last_status_msg")
       
        cfg = ETF_CONFIG.get(name, {})
        strategy_run = cfg.get("strategy_run", "yes").lower()
       
        if status:
            old_time_match = re.search(r'🕒时间:\s*(\d{4}\.\d{2}\.\d{2}\.\d{2}:\d{2})', status)
            if old_time_match:
                status = status.replace(old_time_match.group(1), current_time)
           
            if strategy_run == "no":
                lines.append(f"[仅监控] {status}")
            else:
                lines.append(status)
        else:
            if strategy_run == "no":
                lines.append(f"[仅监控] {name}: 暂无状态记录")
            else:
                lines.append(f"{name}: 暂无状态记录")
   
    snapshot_header = f"🎯 每日快照 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
    return snapshot_header + "\n\n".join(lines)
# ===========================
# 行情数据获取 - 支持A股和港股
# ===========================
def get_price_from_api(symbol, price_scale=1.0, last_known_price=None):
    """
    获取股票价格，支持A股和港股
    策略：
      - A股：EastMoney
      - 港股：新浪（单一接口，不再尝试雅虎）
    """
    raw_symbol = symbol.upper().strip()
    
    if raw_symbol.startswith("HK"):
        # 港股：直接用新浪
        price_info = get_hk_price_tencent(symbol, price_scale)
        return validate_hk_price(
            symbol,
            price_info['price'],
            last_known_price,
            price_info.get('prev_close')
        )
    else:
        # A股：保持原EastMoney接口
        return get_a_price(symbol, price_scale)
def get_a_price(symbol, price_scale=1.0):
    """获取A股价格（保持不变）"""
    if symbol.startswith("SH"):
        market = "1"
        code = symbol[2:]
    else:
        market = "0"
        code = symbol[2:]
    url = f"https://push2.eastmoney.com/api/qt/stock/get?secid={market}.{code}&fields=f43"
    headers = {"User-Agent": "Mozilla/5.0", "Referer": "https://quote.eastmoney.com/"}
    try:
        resp = requests.get(url, headers=headers, timeout=5)
        data = resp.json()
        price_raw = data["data"]["f43"]
        price = price_raw / 100.0 * float(price_scale)
        return round(price, 4)
    except Exception as e:
        logging.error(f"获取A股价格失败 {symbol}: {e}")
        raise
def get_hk_price_tencent(symbol, price_scale):
    """
    腾讯财经港股接口：qt.gtimg.cn
    - 优先用固定字段：price=fields[3], prev_close=fields[4]
    - 如遇格式变化，再兜底：顺序找前两个可转 float 的字段
    """
    hk_code = symbol[2:]  # 例如 "HK00700" -> "00700"
    hk_code = hk_code.zfill(5)  # 港股一般 5 位，不足补 0
    headers = {
        "User-Agent": "Mozilla/5.0",
        "Referer": "https://finance.qq.com/"
    }
    # 两种常见写法：hk00700 / r_hk00700（有些页面示例用 r_hk 前缀）:contentReference[oaicite:1]{index=1}
    urls = [
        f"https://qt.gtimg.cn/q=hk{hk_code}",
        f"https://qt.gtimg.cn/q=r_hk{hk_code}",
    ]
    last_err = None
    for url in urls:
        try:
            resp = requests.get(url, headers=headers, timeout=5)
            resp.encoding = "gbk"  # 腾讯这类接口常见是 gbk/gb2312，设一下更稳
            text = resp.text.strip()
            # 形如：v_hk00700="...~...~614.000~605.000~...";
            m = re.search(r'="([^"]*)"', text)
            if not m:
                raise RuntimeError(f"腾讯 HK {symbol} 返回格式异常: {text[:80]!r}")
            data_str = m.group(1)
            fields = data_str.split("~")
            price = prev_close = None
            # 优先按常见字段位解析：:contentReference[oaicite:2]{index=2}
            if len(fields) > 4:
                try:
                    price = float(fields[3])
                except ValueError:
                    price = None
                try:
                    prev_close = float(fields[4])
                except ValueError:
                    prev_close = None
            # 兜底：从 fields 中依次找出前两个可转 float 的字段
            if price is None:
                for f in fields:
                    try:
                        val = float(f)
                    except ValueError:
                        continue
                    if price is None:
                        price = val
                    elif prev_close is None:
                        prev_close = val
                        break
            if price is None:
                raise RuntimeError(f"腾讯 HK {symbol} 无法解析价格: {data_str!r}")
            if prev_close is None:
                prev_close = price
            return {
                "price": round(price * price_scale, 4),
                "prev_close": round(prev_close * price_scale, 4),
            }
        except Exception as e:
            last_err = e
    raise RuntimeError(f"腾讯 HK {symbol} 获取失败: {last_err}")
def validate_hk_price(symbol, current_price, last_known_price, prev_close):
    """港股价格简单验证（精简版）"""
    if current_price <= 0:
        logging.warning(f"港股{symbol}价格无效，尝试使用上次价格或昨收价")
        if last_known_price and last_known_price > 0:
            return last_known_price
        elif prev_close and prev_close > 0:
            return prev_close
        else:
            raise ValueError(f"无法获取港股{symbol}的有效价格")
   
    return current_price
# ===========================
# 历史 K 线 - 支持A股和港股 (精简版)
# ===========================
def get_history_close(symbol, days=400):
    """
    获取历史收盘价
    策略：A股用新浪，港股用腾讯财经。
    """
    raw_symbol = symbol.upper()
   
    if raw_symbol.startswith("HK"):
        logging.debug(f"获取港股 {symbol} {days}天历史K线")
        return get_hk_history_close_tencent(symbol[2:], days)
    else:
        logging.debug(f"获取A股 {symbol} {days}天历史K线")
        return get_a_history_close(symbol, days)
def get_hk_history_close_tencent(hk_code, days):
    """腾讯财经港股历史数据（更健壮，失败时回退到当前价伪历史）"""
    url = f"http://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param=hk{hk_code},day,,,{days},qfq"
    headers = {"User-Agent": "Mozilla/5.0", "Referer": "https://gu.qq.com/"}
    try:
        resp = requests.get(url, headers=headers, timeout=10)
        data = resp.json()
        stock_data = data.get("data", {}).get(f"hk{hk_code}", {})
        # 有的接口字段可能叫 day，也有可能叫 qfqday，这里都试一下
        klines = stock_data.get("day") or stock_data.get("qfqday") or []
        closes = []
        for k in klines:
            try:
                # k 形如 ["2024-01-02","300.000","xxx","xxx","305.000",...]
                closes.append(float(k[4]))
            except (IndexError, ValueError, TypeError):
                continue
        if len(closes) >= 2:
            # 只保留最近 days 条，防止接口返回太长
            return closes[-days:]
        elif len(closes) == 1:
            # 只有一条，就重复铺满 days
            return [closes[0]] * days
        raise RuntimeError(f"腾讯 HK{hk_code} 历史数据为空或无法解析: {stock_data!r}")
    except Exception as e:
        logging.error(f"获取港股历史K线失败 hk{hk_code}: {e}")
        # 兜底：用当前价构造伪历史，至少保证 MA 计算还能跑
        try:
            symbol = f"HK{hk_code}"
            cur_price = get_price_from_api(symbol)
            logging.warning(f"使用当前价构造伪历史数据: HK{hk_code} = {cur_price}")
            return [cur_price] * days
        except Exception as e2:
            logging.error(f"获取港股当前价以构造伪历史失败 hk{hk_code}: {e2}")
            # 实在不行就往外抛，让上层给出清晰错误信息
            raise
def get_a_history_close(symbol, days):
    """A股历史数据（新浪接口）"""
    if symbol.startswith("SH"):
        s = "sh" + symbol[2:]
    elif symbol.startswith("SZ"):
        s = "sz" + symbol[2:]
    else:
        s = symbol.lower()
   
    url = f"https://quotes.sina.cn/cn/api/openapi.php/CN_MarketDataService.getKLineData?symbol={s}&scale=240&ma=no&datalen={days}"
    headers = {"User-Agent": "Mozilla/5.0"}
   
    resp = requests.get(url, headers=headers, timeout=10)
    data = resp.json()
    part = data["result"]["data"]
   
    klines = part.get("data") if isinstance(part, dict) else part
    closes = [float(k["close"]) for k in klines if k.get("close")]
    return closes
# ===========================
# 计算简单移动平均线 MA（带数据不足处理）
# ===========================
def calc_ma_with_coef(closes, length, min_coef=None, reference_ma=None):
    """
    计算移动平均线，支持历史数据不足时使用系数修正
    Returns:
        ma_value: 均线值
        source: 'f' = full, 'p' = partial, 'c' = coef, 'insufficient_data'
    """
    if len(closes) >= length:
        ma_value = sum(closes[-length:]) / length
        return ma_value, 'p' if len(closes) < length * 2 else 'f'
    elif len(closes) >= max(5, length // 2):
        ma_value = sum(closes) / len(closes)
        return ma_value, 'p'
    elif min_coef is not None and reference_ma is not None:
        ma_value = reference_ma * min_coef
        return ma_value, 'c'
    else:
        return None, 'insufficient_data'
# ===========================
# 横盘指数（MA30 / MA60：方向一致性方案）
# ===========================
def _compute_ma_series(closes, period):
    """计算简单 MA 序列（长度 = len(closes) - period + 1）"""
    if len(closes) < period:
        return []
    ma_series = []
    window_sum = sum(closes[:period])
    ma_series.append(window_sum / period)
    for i in range(period, len(closes)):
        window_sum += closes[i] - closes[i - period]
        ma_series.append(window_sum / period)
    return ma_series
def _ma_directional_sideways_score(ma_series, window):
    """
    使用“方向一致性”计算横盘评分：
      - 取最近 window 天 MA 序列：m[0..window]
      - Δ_i = m[i+1] - m[i]
      - dir_strength = |sum(Δ)| / sum(|Δ|)
          * dir_strength 越接近 1 => 越单边趋势
          * dir_strength 越接近 0 => 越来回震荡
      - sideways_score = 1 - dir_strength
          * sideways_score 越接近 1 => 越横盘
          * sideways_score 越接近 0 => 越趋势
    """
    n = len(ma_series)
    if n < window + 1:
        # 数据太短，给一个中性值，避免乱偏
        return 0.5
   
    seg = ma_series[-(window + 1):] # 长度 window+1
    deltas = [seg[i+1] - seg[i] for i in range(window)]
    sum_abs = sum(abs(d) for d in deltas)
    if sum_abs == 0:
        # 完全走平 => 极端横盘
        return 1.0
    dir_strength = abs(sum(deltas)) / sum_abs # 0~1 趋势强度
    sideways_score = 1.0 - dir_strength # 0~1 横盘强度
    sideways_score = max(0.0, min(1.0, sideways_score))
    return sideways_score
def compute_sideways_index(closes, cfg):
    """
    利用 MA30 / MA60 的“方向一致性”来计算横盘评分（0~1）：
      - 分别计算 MA30 / MA60 序列
      - 对 MA30 取最近 sideways_window_30 天，算出横盘评分 s30
      - 对 MA60 取最近 sideways_window_60 天，算出横盘评分 s60
      - 组合：sideways_score = (1 - w60)*s30 + w60*s60
        其中 w60 = sideways_weight_60
      - 最终：
        * 越接近 1 越“横盘震荡”
        * 越接近 0 越“单边趋势”
    """
    period30 = 30
    period60 = 60
    window30 = int(cfg.get("sideways_window_30", 30))
    window60 = int(cfg.get("sideways_window_60", 20))
    weight60 = float(cfg.get("sideways_weight_60", 0.6))
    weight60 = max(0.0, min(1.0, weight60))
    weight30 = 1.0 - weight60
   
    need_len = max(period30 + window30 + 1, period60 + window60 + 1)
    if len(closes) < need_len:
        return 0.0 # 历史太短，偏向“趋势中”（不给横盘太高分）
   
    ma30_series = _compute_ma_series(closes, period30)
    ma60_series = _compute_ma_series(closes, period60)
    if not ma30_series or not ma60_series:
        return 0.0
   
    s30 = _ma_directional_sideways_score(ma30_series, window30)
    s60 = _ma_directional_sideways_score(ma60_series, window60)
   
    sideways_score = weight30 * s30 + weight60 * s60
    sideways_score = max(0.0, min(1.0, sideways_score))
    return sideways_score
# =======================================
# 推送功能 (PushPlus & Telegram)
# =======================================
PUSHPLUS_TOKEN = os.getenv("PUSHPLUS_TOKEN", "")
PUSHPLUS_URL = "http://www.pushplus.plus/send"
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")
TELEGRAM_API_URL = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage" if TELEGRAM_BOT_TOKEN else ""
def escape_markdown_v2(text: str) -> str:
    """转义Telegram MarkdownV2特殊字符"""
    escape_chars = r'_*[]()~`>#+-=|{}.!'
    result = []
    for char in text:
        if char in escape_chars:
            result.append('\\' + char)
        else:
            result.append(char)
    return ''.join(result)
def escape_markdown(text: str) -> str:
    return escape_markdown_v2(text)
def send_notification(msg):
    """PushPlus + Telegram 双通道推送"""
    all_success = True
   
    # PushPlus
    if PUSHPLUS_TOKEN:
        if len(msg) > 4000:
            pushplus_msg = msg[:4000] + "\n...\n(消息过长，已截断)"
        else:
            pushplus_msg = msg
           
        pushplus_payload = {
            "token": PUSHPLUS_TOKEN,
            "title": "QT",
            "content": pushplus_msg,
            "template": "txt"
        }
        try:
            resp = requests.post(PUSHPLUS_URL, json=pushplus_payload, timeout=10)
            resp_data = resp.json()
            if resp_data.get("code") != 200:
                logging.error(f"PushPlus 推送失败: {resp_data.get('msg', '未知错误')}")
                all_success = False
            else:
                logging.info("✅ PushPlus 推送成功。")
        except Exception as e:
            logging.error(f"PushPlus 推送异常: {e}")
            all_success = False
    else:
        logging.info("未配置 PushPlus Token，跳过该通道推送。")
   
    # Telegram
    if TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID:
        try:
            # 去掉“策略运行状态”这一行
            lines = msg.split('\n')
            filtered_lines = [line for line in lines if "🚦策略运行状态:" not in line]
            msg = '\n'.join(filtered_lines)
           
            escaped_msg = escape_markdown_v2(msg)
            if len(escaped_msg) > 4000:
                escaped_msg = escaped_msg[:4000] + "\n...\n(消息过长，已截断)"
           
            telegram_payload = {
                "chat_id": TELEGRAM_CHAT_ID,
                "text": escaped_msg,
                "parse_mode": "MarkdownV2",
                "disable_web_page_preview": True,
                "disable_notification": False
            }
            resp = requests.post(TELEGRAM_API_URL, json=telegram_payload, timeout=30)
           
            if resp.status_code == 200:
                logging.info("✅ Telegram 推送成功。")
            else:
                try:
                    error_msg = resp.json().get('description', '未知错误')
                except Exception:
                    error_msg = resp.text or '无返回信息'
                logging.error(f"❌ Telegram 推送失败 (状态码{resp.status_code}): {error_msg}")
               
                if resp.status_code == 400 and "can't parse entities" in error_msg:
                    logging.error("可能是消息格式问题，尝试使用纯文本格式...")
                    telegram_payload["parse_mode"] = None
                    telegram_payload["text"] = msg[:4000] + "\n...\n(消息过长，已截断)" if len(msg) > 4000 else msg
                    resp2 = requests.post(TELEGRAM_API_URL, json=telegram_payload, timeout=30)
                    if resp2.status_code == 200:
                        logging.info("✅ Telegram 纯文本推送成功。")
                        return all_success
                all_success = False
        except Exception as e:
            logging.error(f"❌ Telegram 推送异常: {e}")
            all_success = False
    else:
        missing = []
        if not TELEGRAM_BOT_TOKEN:
            missing.append("Bot Token")
        if not TELEGRAM_CHAT_ID:
            missing.append("Chat ID")
        logging.info(f"未配置 Telegram {', '.join(missing)}，跳过该通道推送。")
   
    return all_success
# ===========================
# 区间定义 （底仓建立区 + 趋势区 + 底仓高估卖出区）
# ===========================
def _normalize_multiple_or_percent(value, default_multiple):
    raw = _safe_float(value, default_multiple)
    if raw <= 0:
        return default_multiple
    if raw >= 1.0:
        return raw
    return 1.0 + raw
def get_box_upper_multiple(cfg):
    return _normalize_multiple_or_percent(cfg.get("core_zone_upper_multiple", 1.2), 1.2)
def get_core_sell_start_multiple(cfg):
    return _normalize_multiple_or_percent(cfg.get("core_sell_start_multiple", 1.5), 1.5)
def get_core_sell_step_percent(cfg):
    step = _safe_float(cfg.get("core_sell_step_percent", 0.08), 0.08)
    return max(step, 1e-6)
def get_box_grid_enabled(cfg):
    value = str(cfg.get("box_grid_enabled", "no")).strip().lower()
    return value in {"yes", "true", "1", "on"}
def calculate_core_sell_plan(cfg, target_units):
    pyramid_weights = cfg.get("pyramid_weights", [0.03, 0.055, 0.08, 0.105, 0.13, 0.155, 0.18, 0.205, 0.23, 0.255])
    position_mode = get_position_mode(cfg)
    total_core_units = max(target_units, 0.0)
    if total_core_units <= POSITION_EPSILON:
        return []
    weight_sum = sum(pyramid_weights)
    normalized_weights = [w / weight_sum for w in pyramid_weights]
    sell_plan = []
    for i, weight in enumerate(normalized_weights):
        sell_units = normalize_position_amount(total_core_units * weight, position_mode)
        if i == len(normalized_weights) - 1:
            allocated_so_far = sum(plan["units"] for plan in sell_plan)
            remaining_units = total_core_units - allocated_so_far
            sell_units = normalize_position_amount(remaining_units, position_mode) if remaining_units > POSITION_EPSILON else 0
        if sell_units > POSITION_EPSILON:
            sell_plan.append({
                "step": i + 1,
                "weight": pyramid_weights[i],
                "weight_percent": round(pyramid_weights[i] * 100, 1),
                "units": sell_units
            })
    return sell_plan
def get_core_sell_target_step(current_price, ma150, cfg, total_steps):
    if ma150 <= 0 or total_steps <= 0:
        return 0
    start_multiple = get_core_sell_start_multiple(cfg)
    current_multiple = current_price / ma150
    if current_multiple < start_multiple:
        return 0
    step_pct = get_core_sell_step_percent(cfg)
    step = int((current_multiple - start_multiple) / step_pct) + 1
    return min(max(step, 0), total_steps)
def get_box_upper_price(ma150, cfg):
    return ma150 * get_box_upper_multiple(cfg) if ma150 and ma150 > 0 else 0.0
def get_core_clear_price(ma150, cfg):
    return ma150 * get_core_sell_start_multiple(cfg) if ma150 and ma150 > 0 else 0.0
def get_zone(price, ma150, ma300, cfg):
    """
    根据价格和均线判断区间：
      - price <= MA300 => BELOW_MA300
      - MA300 < price < MA150 => BETWEEN_300_150
      - MA150 <= price < MA150 * core_zone_upper_multiple => BOX_AREA
      - 其上 => ABOVE_120（先卖机动仓，达到更高估时才卖底仓）
    """
    box_upper_multiple = get_box_upper_multiple(cfg)
    if price <= ma300:
        return "BELOW_MA300"
    if ma300 < price < ma150:
        return "BETWEEN_300_150"
    if ma150 <= price < ma150 * box_upper_multiple:
        return "BOX_AREA"
    return "ABOVE_120"
# ===========================
# 日志消息生成函数
# ===========================
def build_status_message(name, symbol, now_str, zone, current_price, last_trade_price, last_trade_side,
                        current_units, current_avg_cost, ma150, ma150_source, ma300, ma300_source,
                        target_units, double_target, sell_price, clear_price,
                        position_mode="absolute", extra_info=""):
    """构建状态日志消息"""
    if last_trade_side == "buy":
        side_label = "（b）"
    elif last_trade_side == "sell":
        side_label = "（s）"
    else:
        side_label = "（买）"
    last_trade_price_msg = f"{last_trade_price:.3f}{side_label}" if last_trade_price is not None else "无"
    msg = (
        f"🟢[INFO]【{name}】 ({symbol})\n"
        f"🕒时间: {now_str}\n"
        f"🍭区间: {zone}\n"
        f"💲当前: {current_price:.3f},上次:{last_trade_price_msg}\n"
        f"⚖️持仓: {format_units_for_display(current_units, position_mode)},成本: {current_avg_cost:.3f}, "
        f"目标: {format_units_for_display(target_units, position_mode)}, 上限: {format_units_for_display(double_target, position_mode)}\n"
        f"🔀MA150={ma150:.3f}({ma150_source}), MA300={ma300:.3f}({ma300_source})，sell={sell_price:.3f}, Clear={clear_price:.3f}"
    )
    if extra_info:
        msg += f"\n{extra_info}"
    return msg
def build_trade_message(name, symbol, now_str, zone, trade_action, trade_price, trade_qty,
                       last_trade_price, last_trade_side, position_after, avg_cost_after, ma150, ma150_source,
                       ma300, ma300_source, target_units, double_target, sell_price, clear_price,
                       position_mode="absolute", trade_qty_display=None, extra_info=""):
    """构建交易推送消息"""
    if last_trade_side == "buy":
        side_label = "（B）"
    elif last_trade_side == "sell":
        side_label = "（S）"
    else:
        side_label = "（B）"
    last_trade_price_msg = f"{last_trade_price:.3f}{side_label}" if last_trade_price is not None else f"{trade_price:.3f}{side_label}"
    if trade_qty_display is None:
        trade_qty_display = format_units_for_display(trade_qty, position_mode)
    msg = (
        f"🎯[TRADE]【{name}】 ({symbol})\n"
        f"🕒时间: {now_str}\n"
        f"🍭区间: {zone}\n"
        f"🗞交易: {trade_action} {trade_qty_display} @ {trade_price:.3f}\n"
        f"💲当前: {trade_price:.3f},上次: {last_trade_price_msg}\n"
        f"⚖️持仓: {format_units_for_display(position_after, position_mode)}, 成本: {avg_cost_after:.3f}, "
        f"目标: {format_units_for_display(target_units, position_mode)}, 上限: {format_units_for_display(double_target, position_mode)}\n"
        f"🔀MA150={ma150:.3f}({ma150_source}), MA300={ma300:.3f}({ma300_source})，sell={sell_price:.3f}, Clear={clear_price:.3f}"
    )
    if extra_info:
        msg += f"\n{extra_info}"
    return msg
def build_stop_message(name, symbol, now_str, zone, current_price, last_trade_price, last_trade_side, ma150, ma150_source, ma300, ma300_source, sell_price, clear_price):
    """构建停止交易消息"""
    if last_trade_side == "buy":
        side_label = "（b）"
    elif last_trade_side == "sell":
        side_label = "（s）"
    else:
        side_label = "（买）"
    last_trade_price_msg = f"{last_trade_price:.3f}{side_label}" if last_trade_price is not None else f"{current_price:.3f}{side_label}"
    return (
        f"🎯[STOP]【{name}】 ({symbol})\n"
        f"🕒时间: {now_str}\n"
        f"🍭区间: {zone}\n"
        f"🛑操作: 停止所有交易\n"
        f"💲当前: {current_price:.3f},上次: {last_trade_price_msg}\n"
        f"🔀MA150={ma150:.3f}({ma150_source}), MA300={ma300:.3f}({ma300_source})，sell={sell_price:.3f}, Clear={clear_price:.3f}"
    )
def build_box_grid_info(last_trade_price, current_price, grid_step, last_grid, current_grid, min_change):
    return f"🌐箱体区: 网格步长={grid_step:.3f}, 上次网格={last_grid}, 当前网格={current_grid}, 最小变动={min_change:.3f}"
def build_trend_info(last_trade_price, current_price, sell_step, last_step, now_step, min_change):
    return f"🎯趋势区: 卖出步长={sell_step:.3f}, 上次步数={last_step}, 当前步数={now_step}, 最小变动={min_change:.3f}"
def build_pyramid_info(position_ratio, current_step, target_step):
    return f"🏛️价值区: 位置={position_ratio:.2%}, 当前步数={current_step}, 目标步数={target_step}"
def build_box_info(target_gap, ma150, box_upper_price, position_mode):
    if target_gap > POSITION_EPSILON:
        return f"🏠底仓建立区: 当前低于目标仓位，进入箱体区时补足到底仓 | 目标缺口={format_units_for_display(target_gap, position_mode)} | 区间={ma150:.3f}~{box_upper_price:.3f}"
    return f"🏠底仓建立区: 目标仓位已建立，箱体区默认不买不卖 | 区间={ma150:.3f}~{box_upper_price:.3f}"
def build_clear_info(current_price, clear_price, current_step, target_step, current_units, target_units, position_mode, cfg):
    start_multiple = get_core_sell_start_multiple(cfg)
    step_pct = get_core_sell_step_percent(cfg)
    current_multiple = current_price / clear_price * start_multiple if clear_price > 0 else 0.0
    action = "未进入" if current_price < clear_price else "已进入"
    return (
        f"🧹Clear区: {action} | 触发价={clear_price:.3f} | 当前倍数={current_multiple:.2f} | "
        f"当前步数={current_step}, 目标步数={target_step} | 剩余底仓={format_units_for_display(min(current_units, target_units), position_mode)} | 档位间隔={step_pct*100:.1f}%"
    )
# ===========================
# 倒金字塔加仓计算函数
# ===========================
def calculate_pyramid_additions(name, cfg, current_units, target_units, double_target, dcf_state):
    position_mode = get_position_mode(cfg)
    pyramid_weights = cfg.get("pyramid_weights", [0.03, 0.055, 0.08, 0.105, 0.13, 0.155, 0.18, 0.205, 0.23, 0.255])
    total_add_units = double_target - current_units
    if total_add_units <= POSITION_EPSILON:
        return []
    weight_sum = sum(pyramid_weights)
    normalized_weights = [w / weight_sum for w in pyramid_weights]
    add_plan = []
    for i, weight in enumerate(normalized_weights):
        add_units = normalize_position_amount(total_add_units * weight, position_mode)
        if i == len(normalized_weights) - 1:
            allocated_so_far = sum(plan["units"] for plan in add_plan)
            remaining_units = total_add_units - allocated_so_far
            if remaining_units > POSITION_EPSILON:
                add_units = normalize_position_amount(remaining_units, position_mode)
            else:
                add_units = 0
        if add_units > POSITION_EPSILON:
            add_plan.append({
                "step": i + 1,
                "weight": pyramid_weights[i],
                "weight_percent": round(pyramid_weights[i] * 100, 1),
                "units": add_units
            })
    return add_plan
# ===========================
# 交易记录函数
# ===========================
def log_trade(dcf_name, symbol, price, qty, side, reason, zone=None,
              pos_before=None, pos_after=None,
              avg_cost_before=None, avg_cost_after=None,
              cash_after=None, total_assets=None,
              last_trade_price_before=None, last_trade_price_after=None,
              last_trade_side_before=None, last_trade_side_after=None,
              position_mode="absolute", qty_display=None):
    file_exists = os.path.isfile(TRADE_LOG_FILE)
    with open(TRADE_LOG_FILE, mode="a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow([
                "date",
                "dcf_name",
                "symbol",
                "price",
                "qty",
                "side",
                "reason",
                "zone",
                "pos_before",
                "pos_after",
                "avg_cost_before",
                "avg_cost_after",
                "last_trade_price_before",
                "last_trade_price_after",
                "last_trade_side_before",
                "last_trade_side_after",
                "cash_after",
                "total_assets",
                "transaction_type",
                "position_mode",
                "qty_display"
            ])
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if "BOX_GRID" in reason:
            trans_type = "GRID"
        elif "ABOVE_120" in reason:
            trans_type = "TREND"
        elif "PYRAMID" in reason or "BETWEEN_300_150" in reason:
            trans_type = "BASE"
        else:
            trans_type = "OTHER"
        writer.writerow([
            now_str,
            dcf_name,
            symbol,
            f"{price:.3f}",
            serialize_numeric(qty),
            side,
            reason,
            zone if zone is not None else "",
            serialize_numeric(pos_before),
            serialize_numeric(pos_after),
            f"{avg_cost_before:.3f}" if avg_cost_before is not None else "",
            f"{avg_cost_after:.3f}" if avg_cost_after is not None else "",
            f"{last_trade_price_before:.3f}" if last_trade_price_before is not None else "",
            f"{last_trade_price_after:.3f}" if last_trade_price_after is not None else "",
            last_trade_side_before if last_trade_side_before is not None else "",
            last_trade_side_after if last_trade_side_after is not None else "",
            serialize_numeric(cash_after),
            serialize_numeric(total_assets),
            trans_type,
            position_mode,
            qty_display or format_units_for_display(qty, position_mode)
        ])
# ===========================
# BETWEEN_300_150 区间：倒金字塔策略
# ===========================
def strategy_between_300_150_pyramid(name, cfg, dcf_state, current_price, ma150, ma300,
                                     current_units, last_trade_price, last_trade_side, target_units,
                                     double_target, now_str, symbol, ma150_source, ma300_source,
                                     dynamic_k150, sideways_score):
    messages = []
    position_mode = get_position_mode(cfg)
    price_diff = ma150 - ma300
    if price_diff <= 0:
        logging.warning(f"{name} 区间参数异常: ma150={ma150}, ma300={ma300}")
        return messages, current_units
    current_avg_cost = dcf_state.get("avg_cost", 0.0)
    if current_units > 0 and current_avg_cost == 0:
        current_avg_cost = current_price
    position_ratio = (ma150 - current_price) / price_diff
    position_ratio = max(0.0, min(1.0, position_ratio))
    total_steps = cfg.get("pyramid_steps", 10)
    target_step = int(position_ratio * total_steps) + 1
    target_step = min(target_step, total_steps)
    current_step = dcf_state.get("pyramid_step", 0)
    if target_step > current_step:
        add_plan = calculate_pyramid_additions(
            name, cfg, current_units, target_units, double_target, dcf_state
        )
        for step_info in add_plan[current_step:target_step]:
            step = step_info["step"]
            weight_percent = step_info["weight_percent"]
            add_units = step_info["units"]
            max_add_units = normalize_position_amount(double_target - current_units, position_mode)
            if add_units > max_add_units:
                add_units = normalize_position_amount(max_add_units, position_mode)
            if add_units > POSITION_EPSILON:
                new_avg_cost = calculate_new_avg_cost(current_units, current_avg_cost, add_units, current_price)
                after_units = normalize_position_amount(current_units + add_units, position_mode)
                trade_qty_display = format_units_for_display(add_units, position_mode)
                log_trade(
                    dcf_name=name,
                    symbol=symbol,
                    price=current_price,
                    qty=add_units,
                    side="BUY",
                    reason=f"PYRAMID_STEP_{step}",
                    zone="BETWEEN_300_150",
                    pos_before=current_units,
                    pos_after=after_units,
                    avg_cost_before=current_avg_cost,
                    avg_cost_after=new_avg_cost,
                    last_trade_price_before=last_trade_price,
                    last_trade_price_after=current_price,
                    last_trade_side_before=last_trade_side,
                    last_trade_side_after="buy",
                    position_mode=position_mode,
                    qty_display=trade_qty_display
                )
                current_units = after_units
                current_avg_cost = new_avg_cost
                dcf_state["current_units"] = current_units
                dcf_state["avg_cost"] = current_avg_cost
                dcf_state["pyramid_step"] = step
                if current_units >= target_units - POSITION_EPSILON and current_price < ma150 * get_core_sell_start_multiple(cfg):
                    dcf_state["core_sell_step"] = 0
                dcf_state["last_trade_price"] = current_price
                dcf_state["last_trade_side"] = "buy"
                dcf_state["position_mode"] = position_mode
                persist_runtime_position_to_config(name, current_units, current_avg_cost)
                if "pyramid_units" not in dcf_state:
                    dcf_state["pyramid_units"] = []
                dcf_state["pyramid_units"].append({
                    "step": step,
                    "price": current_price,
                    "units": add_units,
                    "weight": weight_percent,
                    "timestamp": now_str
                })
                dyn_info = f"\n🏛倒金字塔加仓: 第{step}步 (权重:{weight_percent:.1f}%, 位置:{position_ratio:.2%})"
                dyn_info += f"\n📏本次仓位变动: {trade_qty_display}"
                dyn_info += f"\n⏳动态K={dynamic_k150:.3f}，横盘评分={sideways_score:.2f}"
                trade_msg = build_trade_message(
                    name=name,
                    symbol=symbol,
                    now_str=now_str,
                    zone="BETWEEN_300_150",
                    trade_action="买入",
                    trade_price=current_price,
                    trade_qty=add_units,
                    trade_qty_display=trade_qty_display,
                    last_trade_price=last_trade_price,
                    last_trade_side=last_trade_side,
                    position_after=after_units,
                    avg_cost_after=new_avg_cost,
                    ma150=ma150,
                    ma150_source=ma150_source,
                    ma300=ma300,
                    ma300_source=ma300_source,
                    target_units=target_units,
                    double_target=double_target,
                    sell_price=get_box_upper_price(ma150, cfg),
                    clear_price=get_core_clear_price(ma150, cfg),
                    position_mode=position_mode,
                    extra_info=f"⏳动态K={dynamic_k150:.3f}，横盘评分={sideways_score:.2f}"
                )
                logging.info(trade_msg)
                messages.append(trade_msg)
    return messages, current_units
# ===========================
#        核心策略逻辑
# ===========================
def strategy_for_dcf(name, cfg, state):
    symbol = cfg["symbol"]
    position_mode = get_position_mode(cfg)
    base_units = get_base_units(cfg)
    target_units = get_target_units(cfg)
    double_target = get_double_target(cfg)
    strategy_run = cfg.get("strategy_run", "yes").lower()
    if strategy_run not in ["yes", "no"]:
        strategy_run = "yes"
    dcf_state = state.setdefault(name, build_default_symbol_state(cfg))
    dcf_state = normalize_symbol_state(name, cfg, dcf_state)
    tick = dcf_state.get("tick", 0) + 1
    dcf_state["tick"] = tick
    last_trade_price = dcf_state.get("last_trade_price")
    last_trade_side = dcf_state.get("last_trade_side", "buy")
    last_known_price = dcf_state.get("last_price")
    if last_trade_price is None or last_trade_price <= 0:
        if last_known_price is not None and last_known_price > 0:
            current_price_for_init = last_known_price
        else:
            current_price_for_init = get_price_from_api(
                symbol,
                cfg.get("price_scale", 1.0),
                last_known_price=last_known_price
            )
        last_trade_price = current_price_for_init
        dcf_state["last_trade_price"] = current_price_for_init
        dcf_state["last_trade_side"] = "buy"
        dcf_state["last_price"] = current_price_for_init
    current_units = normalize_position_amount(dcf_state.get("current_units", base_units), position_mode)
    current_avg_cost = dcf_state.get("avg_cost", 0.0)
    live_units = get_live_current_units(cfg)
    live_avg_cost = get_live_current_avg_cost(cfg)
    if live_units is not None and abs(live_units - current_units) > POSITION_EPSILON:
        current_units = live_units
        dcf_state["current_units"] = current_units
        if live_avg_cost is not None:
            current_avg_cost = live_avg_cost
            dcf_state["avg_cost"] = current_avg_cost
        elif current_units <= POSITION_EPSILON:
            current_avg_cost = 0.0
            dcf_state["avg_cost"] = 0.0
    elif live_avg_cost is not None and abs(live_avg_cost - current_avg_cost) > POSITION_EPSILON:
        current_avg_cost = live_avg_cost
        dcf_state["avg_cost"] = current_avg_cost
    current_price = get_price_from_api(
        symbol,
        cfg.get("price_scale", 1.0),
        last_known_price=dcf_state.get("last_price")
    )
    closes = get_history_close(symbol, STRATEGY.get("fetch_history_days", 400))
    ma_short_len = STRATEGY.get("ma_period_short", 150)
    ma_long_len = STRATEGY.get("ma_period_long", 300)
    ma150_raw, ma150_source = calc_ma_with_coef(closes, ma_short_len)
    if ma150_raw is None:
        msg = (
            f"🎯[ERROR]【{name}】 ({symbol})\n"
            f"🕒时间: {datetime.now().strftime('%Y.%m.%d.%H:%M')}\n"
            f"❌历史数据严重不足，无法计算MA150\n"
            f"数据长度: {len(closes)}\n"
            f"当前: {current_price:.3f}"
        )
        logging.info(msg)
        dcf_state["last_status_msg"] = msg
        dcf_state["last_price"] = current_price
        return []
    sideways_score = float(compute_sideways_index(closes, cfg))
    base_k150 = float(cfg.get("k150", 1.0))
    min_k150 = float(cfg.get("sideways_min_k150", 0.85))
    if base_k150 < min_k150:
        min_k150 = base_k150
    dynamic_k150 = min_k150 + (base_k150 - min_k150) * (1.0 - sideways_score)
    ma150 = ma150_raw * dynamic_k150
    ma300_min_coef = cfg.get("ma300_min_coef", 0.85)
    ma300_raw, ma300_source = calc_ma_with_coef(closes, ma_long_len)
    if ma300_raw is not None:
        base_k300 = cfg.get("k300", 1.0)
        ma300_coef = ma300_raw * base_k300
        ma300_alt = ma150 * ma300_min_coef
        ma300 = min(ma300_coef, ma300_alt)
        ma_long_source = "original" if ma300 == ma300_coef else "c"
    else:
        ma300 = ma150 * ma300_min_coef
        ma_long_source = "c"
        ma300_raw = None
    dcf_state["ma_short_raw"] = ma150_raw
    dcf_state["ma_long_raw"] = ma300_raw
    dcf_state["ma_short"] = ma150
    dcf_state["ma_long"] = ma300
    dcf_state["k150"] = base_k150
    dcf_state["dynamic_k150"] = dynamic_k150
    dcf_state["sideways_score"] = sideways_score
    dcf_state["k300"] = cfg.get("k300", 1.0) if ma300_raw is not None else None
    dcf_state["last_price"] = current_price
    dcf_state["current_units"] = current_units
    dcf_state["ma_long_source"] = ma_long_source
    dcf_state["ma_short_source"] = ma150_source
    dcf_state["position_mode"] = position_mode
    if current_units > 0 and current_avg_cost == 0:
        current_avg_cost = current_price
        dcf_state["avg_cost"] = current_avg_cost
    zone = get_zone(current_price, ma150, ma300, cfg)
    now_str = datetime.now().strftime("%Y.%m.%d.%H:%M")
    sell_price = get_box_upper_price(ma150, cfg)
    clear_price = get_core_clear_price(ma150, cfg)
    extra_info = ""
    if zone == "BOX_AREA":
        target_gap = normalize_position_amount(max(target_units - current_units, 0.0), position_mode)
        box_upper_price = get_box_upper_price(ma150, cfg)
        extra_info = build_box_info(target_gap, ma150, box_upper_price, position_mode)
        if get_box_grid_enabled(cfg) and target_gap <= POSITION_EPSILON:
            grid_pct = _safe_float(cfg.get("grid_box_percent", 0.01), 0.01)
            if grid_pct <= 0:
                grid_pct = 0.01
            if last_trade_price is None or last_trade_price <= 0:
                last_trade_price = current_price
                dcf_state["last_trade_price"] = current_price
                dcf_state["last_trade_side"] = dcf_state.get("last_trade_side", "buy")
            grid_step = max(last_trade_price * grid_pct, 1e-6)
            last_grid = math.floor((last_trade_price - ma150) / grid_step)
            current_grid = math.floor((current_price - ma150) / grid_step)
            min_change = last_trade_price * grid_pct
            PLACEHOLDER
    elif zone == "ABOVE_120":
        sell_up_pct = float(cfg.get("sell_trigger_up_percent", 0.01))
        if sell_up_pct <= 0:
            logging.warning(f"{name} 趋势卖出触发百分比(sell_trigger_up_percent)配置异常<=0，使用默认0.01")
            sell_up_pct = 0.01
        if last_trade_price is None or last_trade_price <= 0:
            last_trade_price = current_price
            dcf_state["last_trade_price"] = current_price
            dcf_state["last_trade_side"] = dcf_state.get("last_trade_side", "buy")
        sell_step = last_trade_price * sell_up_pct
        last_step = math.floor((last_trade_price - ma150) / sell_step)
        now_step = math.floor((current_price - ma150) / sell_step)
        min_change = last_trade_price * sell_up_pct
        core_sell_plan = calculate_core_sell_plan(cfg, target_units)
        target_core_step = get_core_sell_target_step(current_price, ma150, cfg, len(core_sell_plan))
        current_core_step = int(dcf_state.get("core_sell_step", 0))
        excess_units = normalize_position_amount(max(current_units - target_units, 0.0), position_mode)
        extra_info = build_trend_info(last_trade_price, current_price, sell_step, last_step, now_step, min_change)
        extra_info += f"\n🗂趋势仓位: 机动仓={format_units_for_display(excess_units, position_mode)} | 目标={format_units_for_display(target_units, position_mode)} | 上限={format_units_for_display(double_target, position_mode)}"
        extra_info += f"\n{build_clear_info(current_price, clear_price, current_core_step, target_core_step, current_units, target_units, position_mode, cfg)}"
    elif zone == "BETWEEN_300_150":
        price_diff = ma150 - ma300
        if price_diff > 0:
            position_ratio = (ma150 - current_price) / price_diff
            position_ratio = max(0.0, min(1.0, position_ratio))
            total_steps = cfg.get("pyramid_steps", 10)
            target_step = int(position_ratio * total_steps) + 1
            target_step = min(target_step, total_steps)
            current_step = dcf_state.get("pyramid_step", 0)
            extra_info = build_pyramid_info(position_ratio, current_step, target_step)
    dynamic_info = f"⏳动态K={dynamic_k150:.3f}，横盘评分={sideways_score:.2f}"
    if extra_info:
        extra_info_full = extra_info + "\n" + dynamic_info
    else:
        extra_info_full = dynamic_info
    status_suffix = f"\n🚦策略运行状态: {strategy_run.upper()}"
    status_msg = build_status_message(
        name=name,
        symbol=symbol,
        now_str=now_str,
        zone=zone,
        current_price=current_price,
        last_trade_price=last_trade_price,
        last_trade_side=last_trade_side,
        current_units=current_units,
        current_avg_cost=current_avg_cost,
        ma150=ma150,
        ma150_source=ma150_source,
        ma300=ma300,
        ma300_source=ma_long_source,
        target_units=target_units,
        double_target=double_target,
        sell_price=sell_price,
        clear_price=clear_price,
        position_mode=position_mode,
        extra_info=extra_info_full
    )
    logging.info(status_msg)
    dcf_state["last_status_msg"] = status_msg
    if strategy_run == "no":
        return []
    messages = []
    if zone == "BELOW_MA300":
        stop_msg = build_stop_message(
            name=name,
            symbol=symbol,
            now_str=now_str,
            zone=zone,
            current_price=current_price,
            last_trade_price=last_trade_price,
            last_trade_side=last_trade_side,
            ma150=ma150,
            ma150_source=ma150_source,
            ma300=ma300,
            ma300_source=ma_long_source,
            sell_price=sell_price,
            clear_price=clear_price
        )
        logging.info(stop_msg)
        dcf_state["last_status_msg"] = stop_msg
        return messages
    if zone == "BETWEEN_300_150":
        msgs, updated_units = strategy_between_300_150_pyramid(
            name=name,
            cfg=cfg,
            dcf_state=dcf_state,
            current_price=current_price,
            ma150=ma150,
            ma300=ma300,
            current_units=current_units,
            last_trade_price=last_trade_price,
            last_trade_side=last_trade_side,
            target_units=target_units,
            double_target=double_target,
            now_str=now_str,
            symbol=symbol,
            ma150_source=ma150_source,
            ma300_source=ma_long_source,
            dynamic_k150=dynamic_k150,
            sideways_score=sideways_score
        )
        messages.extend(msgs)
        dcf_state["current_units"] = updated_units
        return messages
    if zone == "BOX_AREA":
        target_gap = normalize_position_amount(max(target_units - current_units, 0.0), position_mode)
        if target_gap <= POSITION_EPSILON:
            return messages
        new_avg_cost = calculate_new_avg_cost(current_units, current_avg_cost, target_gap, current_price)
        after_units = normalize_position_amount(current_units + target_gap, position_mode)
        trade_qty_display = format_units_for_display(target_gap, position_mode)
        log_trade(
            dcf_name=name,
            symbol=symbol,
            price=current_price,
            qty=target_gap,
            side="BUY",
            reason="BOX_CORE_BUILD",
            zone=zone,
            pos_before=current_units,
            pos_after=after_units,
            avg_cost_before=current_avg_cost,
            avg_cost_after=new_avg_cost,
            last_trade_price_before=last_trade_price,
            last_trade_price_after=current_price,
            last_trade_side_before=last_trade_side,
            last_trade_side_after="buy",
            position_mode=position_mode,
            qty_display=trade_qty_display
        )
        current_units = after_units
        current_avg_cost = new_avg_cost
        dcf_state["current_units"] = current_units
        dcf_state["avg_cost"] = current_avg_cost
        dcf_state["core_sell_step"] = 0
        dcf_state["last_trade_price"] = current_price
        dcf_state["last_trade_side"] = "buy"
        persist_runtime_position_to_config(name, current_units, current_avg_cost)
        box_info = build_box_info(target_gap, ma150, get_box_upper_price(ma150, cfg), position_mode)
        box_info += f"\n📏本次仓位变动: {trade_qty_display}"
        box_info += f"\n⏳动态K={dynamic_k150:.3f}，横盘评分={sideways_score:.2f}"
        trade_msg = build_trade_message(
            name=name,
            symbol=symbol,
            now_str=now_str,
            zone="BOX_AREA",
            trade_action="买入",
            trade_price=current_price,
            trade_qty=target_gap,
            trade_qty_display=trade_qty_display,
            last_trade_price=last_trade_price,
            last_trade_side=last_trade_side,
            position_after=after_units,
            avg_cost_after=new_avg_cost,
            ma150=ma150,
            ma150_source=ma150_source,
            ma300=ma300,
            ma300_source=ma_long_source,
            target_units=target_units,
            double_target=double_target,
            sell_price=sell_price,
            clear_price=clear_price,
            position_mode=position_mode,
            extra_info=box_info
        )
        logging.info(trade_msg)
        messages.append(trade_msg)
        return messages
    if zone == "ABOVE_120":
        sell_up_pct = float(cfg.get("sell_trigger_up_percent", 0.01))
        if sell_up_pct <= 0:
            logging.warning(f"{name} 趋势卖出触发百分比(sell_trigger_up_percent)配置异常<=0，使用默认0.01")
            sell_up_pct = 0.01
        if last_trade_price is None or last_trade_price <= 0:
            last_trade_price = current_price
            dcf_state["last_trade_price"] = current_price
            dcf_state["last_trade_side"] = dcf_state.get("last_trade_side", "buy")
        sell_step = last_trade_price * sell_up_pct
        last_step = math.floor((last_trade_price - ma150) / sell_step)
        now_step = math.floor((current_price - ma150) / sell_step)
        min_change = last_trade_price * sell_up_pct
        core_sell_start_price = ma150 * get_core_sell_start_multiple(cfg)
        core_sell_plan = calculate_core_sell_plan(cfg, target_units)
        target_core_step = get_core_sell_target_step(current_price, ma150, cfg, len(core_sell_plan))
        current_core_step = int(dcf_state.get("core_sell_step", 0))
        if now_step > last_step and abs(current_price - last_trade_price) >= min_change:
            step_diff = now_step - last_step
            requested_sell_units = get_step_trade_units(cfg, "sell_percent", step_diff)
            excess_units = normalize_position_amount(max(current_units - target_units, 0.0), position_mode)
            sell_units = normalize_position_amount(min(requested_sell_units, excess_units), position_mode)
            if sell_units > POSITION_EPSILON:
                after_units = normalize_position_amount(max(current_units - sell_units, 0.0), position_mode)
                trade_qty_display = format_units_for_display(sell_units, position_mode)
                log_trade(
                    dcf_name=name,
                    symbol=symbol,
                    price=current_price,
                    qty=sell_units,
                    side="SELL",
                    reason="ABOVE_120_EXCESS_SELL",
                    zone=zone,
                    pos_before=current_units,
                    pos_after=after_units,
                    avg_cost_before=current_avg_cost,
                    avg_cost_after=current_avg_cost if after_units > POSITION_EPSILON else 0,
                    last_trade_price_before=last_trade_price,
                    last_trade_price_after=current_price,
                    last_trade_side_before=last_trade_side,
                    last_trade_side_after="sell",
                    position_mode=position_mode,
                    qty_display=trade_qty_display
                )
                current_units = after_units
                dcf_state["current_units"] = current_units
                dcf_state["last_trade_price"] = current_price
                dcf_state["last_trade_side"] = "sell"
                trend_info = build_trend_info(last_trade_price, current_price, sell_step, last_step, now_step, min_change)
                trend_info += f"\n📏本次仓位变动: {trade_qty_display}"
                trend_info += f"\n🗂趋势仓位: 机动仓={format_units_for_display(max(after_units - target_units, 0.0), position_mode)} | 目标={format_units_for_display(target_units, position_mode)} | 上限={format_units_for_display(double_target, position_mode)}"
                trend_info += f"\n{build_clear_info(current_price, clear_price, int(dcf_state.get('core_sell_step', 0)), target_core_step, after_units, target_units, position_mode, cfg)}"
                trend_info += f"\n⏳动态K={dynamic_k150:.3f}，横盘评分={sideways_score:.2f}"
                trade_msg = build_trade_message(
                    name=name,
                    symbol=symbol,
                    now_str=now_str,
                    zone="ABOVE_120",
                    trade_action="卖出",
                    trade_price=current_price,
                    trade_qty=sell_units,
                    trade_qty_display=trade_qty_display,
                    last_trade_price=last_trade_price,
                    last_trade_side=last_trade_side,
                    position_after=after_units,
                    avg_cost_after=current_avg_cost,
                    ma150=ma150,
                    ma150_source=ma150_source,
                    ma300=ma300,
                    ma300_source=ma_long_source,
                    target_units=target_units,
                    double_target=double_target,
                    sell_price=sell_price,
                    clear_price=clear_price,
                    position_mode=position_mode,
                    extra_info=trend_info
                )
                logging.info(trade_msg)
                messages.append(trade_msg)
        if target_core_step > current_core_step:
            for step_info in core_sell_plan[current_core_step:target_core_step]:
                core_sell_units = normalize_position_amount(min(step_info["units"], min(current_units, target_units)), position_mode)
                if core_sell_units <= POSITION_EPSILON:
                    current_core_step = step_info["step"]
                    dcf_state["core_sell_step"] = current_core_step
                    continue
                after_units = normalize_position_amount(max(current_units - core_sell_units, 0.0), position_mode)
                trade_qty_display = format_units_for_display(core_sell_units, position_mode)
                reason = f"ABOVE_120_CORE_PYRAMID_SELL_STEP_{step_info['step']}"
                log_trade(
                    dcf_name=name,
                    symbol=symbol,
                    price=current_price,
                    qty=core_sell_units,
                    side="SELL",
                    reason=reason,
                    zone=zone,
                    pos_before=current_units,
                    pos_after=after_units,
                    avg_cost_before=current_avg_cost,
                    avg_cost_after=current_avg_cost if after_units > POSITION_EPSILON else 0,
                    last_trade_price_before=dcf_state.get("last_trade_price", last_trade_price),
                    last_trade_price_after=current_price,
                    last_trade_side_before=dcf_state.get("last_trade_side", last_trade_side),
                    last_trade_side_after="sell",
                    position_mode=position_mode,
                    qty_display=trade_qty_display
                )
                current_units = after_units
                dcf_state["current_units"] = current_units
                dcf_state["last_trade_price"] = current_price
                dcf_state["last_trade_side"] = "sell"
                current_core_step = step_info["step"]
                dcf_state["core_sell_step"] = current_core_step
                start_multiple = get_core_sell_start_multiple(cfg)
                step_multiple = start_multiple + (step_info["step"] - 1) * get_core_sell_step_percent(cfg)
                trend_info = build_trend_info(last_trade_price, current_price, sell_step, last_step, now_step, min_change)
                trend_info += f"\n🧹Clear区: 已进入 | 第{step_info['step']}步 (权重:{step_info['weight_percent']:.1f}%, 档位≈MA150*{step_multiple:.2f})"
                trend_info += f"\n📏本次仓位变动: {trade_qty_display}"
                trend_info += f"\n🗂清仓仓位: 剩余底仓={format_units_for_display(min(after_units, target_units), position_mode)} | 当前步数={current_core_step}, 目标步数={target_core_step}"
                trend_info += f"\n⏳动态K={dynamic_k150:.3f}，横盘评分={sideways_score:.2f}"
                trade_msg = build_trade_message(
                    name=name,
                    symbol=symbol,
                    now_str=now_str,
                    zone="ABOVE_120",
                    trade_action="卖出",
                    trade_price=current_price,
                    trade_qty=core_sell_units,
                    trade_qty_display=trade_qty_display,
                    last_trade_price=dcf_state.get("last_trade_price", last_trade_price),
                    last_trade_side=dcf_state.get("last_trade_side", last_trade_side),
                    position_after=after_units,
                    avg_cost_after=current_avg_cost,
                    ma150=ma150,
                    ma150_source=ma150_source,
                    ma300=ma300,
                    ma300_source=ma_long_source,
                    target_units=target_units,
                    double_target=double_target,
                    sell_price=sell_price,
                    clear_price=clear_price,
                    position_mode=position_mode,
                    extra_info=trend_info
                )
                logging.info(trade_msg)
                messages.append(trade_msg)
        return messages
    logging.warning(f"🎯[WARNING]{name} ({symbol})🎯 未知区间: {zone}")
    return messages
# ===========================
# 日志清理函数
# 目标：dcf/log/ 下， dcf.log 按最近时间保留 int 份，其余删除
# ===========================
def clean_old_dcf_logs(
    log_dir: str,
    keep: int = 7,
    filename_pattern: str = r"^dcf\.(\d{8})\.log$",
):
    """
    清理 log_dir 下匹配 dcf.YYYYMMDD.log 的历史日志：
    - 按日期倒序保留 keep 份
    - 其余删除
    - 不匹配该格式的文件不会动（更安全）
    返回: (kept_files, removed_files)
    """
    if keep <= 0:
        keep = 0
    if not os.path.isdir(log_dir):
        logging.warning(f"⚠️ 日志目录不存在，跳过清理: {log_dir}")
        return [], []
    rx = re.compile(filename_pattern)
    candidates = []
    for fn in os.listdir(log_dir):
        m = rx.match(fn)
        if not m:
            continue
        date_str = m.group(1)  # YYYYMMDD
        try:
            dt = datetime.strptime(date_str, "%Y%m%d")
        except ValueError:
            continue
        full_path = os.path.join(log_dir, fn)
        candidates.append((dt, full_path))
    # 日期从新到旧
    candidates.sort(key=lambda x: x[0], reverse=True)
    kept = [p for _, p in candidates[:keep]]
    to_remove = [p for _, p in candidates[keep:]]
    removed = []
    for path in to_remove:
        try:
            os.remove(path)
            removed.append(path)
        except Exception as e:
            logging.error(f"❌ 删除旧日志失败: {path} | {e}")
    if candidates:
        logging.info(
            f"🧹 日志清理完成：共匹配 {len(candidates)} 份，保留 {len(kept)} 份，删除 {len(removed)} 份"
        )
        for p in removed:
            logging.info(f"🗑️ 已删除旧日志: {os.path.basename(p)}")
    else:
        logging.info("🧹 日志清理：未发现符合 dcf.YYYYMMDD.log 格式的日志，无需清理")
    return kept, removed
# ===========================
# 主循环
# ===========================
def main_loop():
    logging.info("=" * 60)
    logging.info("DCF策略启动完成")
    logging.info(f"当前时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logging.info("=" * 60)
    config_path = os.path.join(BASE_DIR, "dcf.yaml")
    global ETF_CONFIG, STRATEGY, FULL_CONFIG
    ETF_CONFIG, STRATEGY_from_conf, FULL_CONFIG = load_config(config_path)
    STRATEGY.update(STRATEGY_from_conf)
    logging.info("📌 各标的策略运行状态:")
    for name, cfg in ETF_CONFIG.items():
        strategy_run = cfg.get("strategy_run", "yes").lower()
        status_icon = "🟢" if strategy_run == "yes" else "🔴"
        logging.info(f" {status_icon} {name}: {strategy_run.upper()}")
    logging.info("=" * 60)
    state = load_state()
    if "_meta" not in state:
        state["_meta"] = {
            "last_daily_push_date": None,
            "last_log_rotate_date": None,
        }
    while True:
        ETF_CONFIG, STRATEGY_from_conf, FULL_CONFIG = load_config(config_path)
        STRATEGY.update(STRATEGY_from_conf)
        now = datetime.now()
        # ========= 日志轮转 =========
        if should_rotate_logs(state, now):
            logging.info("=" * 60)
            logging.info(f"🔄 开始执行日志轮转 - {now.strftime('%Y-%m-%d %H:%M:%S')}")
            logging.info("=" * 60)
            rotate_success = rotate_and_backup_logs(now)
            if rotate_success:
                log_dir = os.path.join(BASE_DIR, "log")
                try:
                    clean_old_dcf_logs(log_dir=log_dir, keep=7)
                except Exception as e:
                    logging.exception(f"❌ 执行日志清理函数失败: {e}")
                snapshot = build_daily_snapshot(state)
                logging.info("=" * 60)
                logging.info("📌每日快照内容:")
                logging.info("=" * 60)
                logging.info(snapshot)
                logging.info("=" * 60)
                try:
                    send_notification(snapshot)
                    logging.info("✅ 每日快照推送成功")
                except Exception as e:
                    logging.error(f"❌ 推送每日快照失败: {e}")
                state["_meta"]["last_log_rotate_date"] = now.date().isoformat()
                state["_meta"]["last_daily_push_date"] = now.date().isoformat()
                save_state(state)
                logging.info("=" * 60)
                logging.info("✅ 日志轮转与快照推送完成")
                logging.info("🕒 下次轮转时间: 明天 09:00")
                logging.info("=" * 60)
        # ========= 非交易时段 =========
        if not in_trade_session(now):
            time_module.sleep(STRATEGY.get("loop_interval", 60))
            continue
        # ========= 策略执行 =========
        all_trade_msgs = []
        for name, cfg in ETF_CONFIG.items():
            try:
                msgs = strategy_for_dcf(name, cfg, state)
                if msgs:
                    all_trade_msgs.extend(msgs)
            except Exception as e:
                logging.exception(f"{name} 策略执行出错: {e}")
        save_state(state)
        # ========= 推送交易信号 =========
        if all_trade_msgs:
            body = "\n\n".join(all_trade_msgs)
            logging.info("=" * 60)
            logging.info("📨 推送买卖信号:")
            logging.info("=" * 60)
            logging.info(body)
            try:
                send_notification(body)
                logging.info("✅ 买卖信号推送成功")
            except Exception:
                logging.exception("❌ 推送买卖信号失败")
            logging.info("=" * 60)
        time_module.sleep(STRATEGY.get("loop_interval", 60))
if __name__ == "__main__":
    try:
        main_loop()
    except KeyboardInterrupt:
        logging.info("用户中断程序执行")
    except Exception as e:
        logging.exception(f"程序异常退出: {e}")

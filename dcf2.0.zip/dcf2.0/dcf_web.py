#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import ast
import json
import re
import secrets
import subprocess
import sys
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Tuple

from flask import (
    Flask,
    abort,
    flash,
    redirect,
    render_template,
    request,
    send_file,
    session,
    url_for,
)
from ruamel.yaml import YAML
from ruamel.yaml.constructor import DuplicateKeyError
import yaml as pyyaml
from werkzeug.security import check_password_hash

BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "dcf.yaml"
STATE_FILE = BASE_DIR / "dcf_monitor_state.json"
WEB_CONFIG_FILE = BASE_DIR / "web_portal.json"
BACKTEST_FILE = BASE_DIR / "backtest_dcf.py"
TRADE_LOG_FILE = BASE_DIR / "trade_log.csv"
BACKTEST_OUT_DIR = BASE_DIR / "backtest_out"

yaml = YAML()
yaml.preserve_quotes = True
yaml.indent(mapping=2, sequence=4, offset=2)
yaml.width = 4096

app = Flask(
    __name__,
    template_folder=str(BASE_DIR / "web_templates"),
    static_folder=str(BASE_DIR / "web_static"),
)

APP_DISPLAY_NAME = "闲云量化"

PAGE_TITLES = {
    "symbols": "标的",
    "status": "状态",
    "params": "参数",
    "backtest": "回测",
    "analysis": "分析",
}

PARAM_HELP: Dict[str, str] = {
    "k150": "MA150 的动态倍率基准。值越大，MA150 上沿越宽，越不容易进入高估/趋势卖出区。",
    "k300": "MA300 的动态倍率基准。用于下方价值区判断。值越大，MA300 参考带越宽。",
    "ma300_min_coef": "MA300 的最低压缩系数。横盘或特殊情况下，MA300 下沿不会低于这个比例。",
    "sideways_window_30": "用最近多少天的 MA30 变化来评估横盘程度。窗口越小越灵敏，越大越平滑。",
    "sideways_window_60": "用最近多少天的 MA60 变化来评估横盘程度。窗口越小越灵敏，越大越平滑。",
    "sideways_weight_60": "横盘评分中，MA60 所占权重。越大越偏向中期横盘判断。",
    "sideways_min_k150": "横盘评分很高时，动态 K150 最低可压到的值。数值越小，箱体上沿越容易下移。",
}

BACKTEST_HELP_TEXT = """1) 信号使用 Adj Close；成交/估值使用 Close。
2) 分红按除息日入账；拆股按除权日调整成本。
3) 若 symbol 不在 ETF_CONFIG 中，会自动使用 COMMON_BACKTEST_CONFIG 的通用参数。
4) --base-units 可覆盖配置中的初始仓位；若未给 --target-units，则默认自动取 base 的 2 倍。
5) BOX_AREA 会优先把仓位补足到目标仓位；若 box_grid_enabled=yes，目标仓位建立后按箱体网格交易；否则默认不买不卖。
6) ABOVE_120 在 MA150*core_sell_start_multiple 之前，只卖超过目标仓位的机动仓。
7) 达到 MA150*core_sell_start_multiple 后，底仓按正金字塔逐步卖出。
8) 百分比模式下，qty / pos_after 表示仓位比例（成本口径），不是股数。
9) 百分比模式下，已实现/浮动收益展示的是对总账户收益贡献的估算值。
10) trades_csv 已记录每笔成交时的 raw_close / adj_close / ma150 / ma300。"""

FIELD_GROUPS: List[Dict[str, Any]] = [
    {
        "id": "basic",
        "title": "基础信息",
        "items": [
            ("symbol", "代码", "text"),
            ("price_scale", "价格缩放", "number"),
            ("strategy_run", "运行状态", "select_yes_no"),
        ],
    },
    {
        "id": "position",
        "title": "仓位参数",
        "items": [
            ("base_units", "初始仓位", "text"),
            ("target_units", "目标仓位", "text"),
            ("double_target_factor", "上限倍数", "number"),
            ("current_units", "当前实时持仓", "text"),
            ("current_avg_cost", "当前持仓成本", "number"),
        ],
    },
    {
        "id": "sideways",
        "title": "均线与横盘",
        "items": [
            ("k150", "k150", "number"),
            ("k300", "k300", "number"),
            ("ma300_min_coef", "ma300最小系数", "number"),
            ("sideways_window_30", "横盘窗口30", "number"),
            ("sideways_window_60", "横盘窗口60", "number"),
            ("sideways_weight_60", "横盘权重60", "number"),
            ("sideways_min_k150", "横盘最小k150", "number"),
        ],
    },
    {
        "id": "zones",
        "title": "箱体 / 趋势 / Clear",
        "items": [
            ("core_zone_upper_multiple", "箱体上沿倍数", "number"),
            ("box_grid_enabled", "箱体区网格", "select_yes_no"),
            ("grid_box_percent", "箱体网格步长", "number"),
            ("grid_box_units_percent", "箱体交易比例", "number"),
            ("core_sell_start_multiple", "Clear区倍数", "number"),
            ("core_sell_step_percent", "Clear区步长", "number"),
            ("sell_percent", "趋势区卖出比例", "number"),
            ("sell_trigger_up_percent", "趋势区步长", "number"),
        ],
    },
    {
        "id": "value",
        "title": "价值区 / 金字塔",
        "items": [
            ("pyramid_steps", "倒金字塔步数", "number"),
            ("pyramid_weights", "倒金字塔权重", "text"),
        ],
    },
]

SELECT_FIELD_OPTIONS = {
    "strategy_run": [("yes", "yes"), ("no", "no")],
    "box_grid_enabled": [("no", "no"), ("yes", "yes")],
}

SUMMARY_KEYS = [
    "标的", "模式", "K线数量",
    "最大回撤(参考)", "结束总权益(参考)", "结束价值(参考)",
    "已实现收益贡献(参考)", "已实现收益(参考)",
    "浮动收益贡献(参考)", "浮动盈亏(参考)",
    "综合收益率(参考)", "个股收益(持仓部分)",
    "期末现金权重", "期末现金",
    "期末持仓(成本口径)", "期末持仓",
    "期末估算市值权重", "期末持仓市值",
    "首次建仓日", "首次建仓原始价", "首次建仓复权价",
    "最新原始价", "最新复权价",
]


def default_web_config() -> Dict[str, Any]:
    return {
        "app_name": APP_DISPLAY_NAME,
        "admin_username": "admin",
        "password_hash": "",
        "secret_key": secrets.token_hex(32),
        "domain": "sharq.eu.org",
        "public_port": 819,
        "internal_port": 1819,
    }


def load_web_config() -> Dict[str, Any]:
    if not WEB_CONFIG_FILE.exists():
        cfg = default_web_config()
        WEB_CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        return cfg
    raw = WEB_CONFIG_FILE.read_text(encoding="utf-8").strip()
    if not raw:
        cfg = default_web_config()
        WEB_CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        return cfg
    try:
        return json.loads(raw)
    except Exception:
        try:
            cfg = ast.literal_eval(raw)
            if isinstance(cfg, dict):
                merged = default_web_config()
                merged.update(cfg)
                WEB_CONFIG_FILE.write_text(json.dumps(merged, ensure_ascii=False, indent=2), encoding="utf-8")
                return merged
        except Exception:
            pass
    cfg = default_web_config()
    WEB_CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return cfg


def init_app_secret() -> None:
    cfg = load_web_config()
    app.secret_key = cfg.get("secret_key") or secrets.token_hex(32)


init_app_secret()


def normalize_config(data: Dict[str, Any]) -> bool:
    changed = False
    common = data.get("COMMON_BACKTEST_CONFIG")
    if isinstance(common, dict):
        for k in ["pyramid_enabled", "fee_rate", "slippage_bp", "stop_add_above_percent"]:
            if k in common:
                common.pop(k, None)
                changed = True
        if common.get("strategy_run") not in {"yes", "no"}:
            common["strategy_run"] = "no"
            changed = True
        if common.get("box_grid_enabled") not in {"yes", "no"}:
            common["box_grid_enabled"] = "no"
            changed = True

    etf_cfg = data.get("ETF_CONFIG")
    if isinstance(etf_cfg, dict):
        for _, section in etf_cfg.items():
            if not isinstance(section, dict):
                continue
            for k in ["pyramid_enabled", "fee_rate", "slippage_bp", "stop_add_above_percent"]:
                if k in section:
                    section.pop(k, None)
                    changed = True
            if section.get("strategy_run") not in {"yes", "no"}:
                section["strategy_run"] = "no"
                changed = True
            if section.get("box_grid_enabled") not in {"yes", "no"}:
                section["box_grid_enabled"] = "no"
                changed = True
    return changed


def read_yaml() -> Dict[str, Any]:
    if not CONFIG_FILE.exists():
        return {}
    raw = CONFIG_FILE.read_text(encoding="utf-8")
    try:
        data = yaml.load(raw) or {}
    except DuplicateKeyError:
        data = pyyaml.safe_load(raw) or {}
        if isinstance(data, dict):
            write_yaml(data)
    if isinstance(data, dict) and normalize_config(data):
        write_yaml(data)
    return data


def write_yaml(data: Dict[str, Any]) -> None:
    normalize_config(data)
    with CONFIG_FILE.open("w", encoding="utf-8") as f:
        yaml.dump(data, f)


def read_state() -> Dict[str, Any]:
    if not STATE_FILE.exists():
        return {}
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def write_state(data: Dict[str, Any]) -> None:
    try:
        STATE_FILE.write_text(json.dumps(data or {}, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def delete_symbol_state(selected: str, symbol_code: str = "") -> None:
    state = read_state()
    if not isinstance(state, dict):
        return
    changed = False
    if selected in state:
        state.pop(selected, None)
        changed = True
    code = (symbol_code or "").strip().upper()
    if code and code in state:
        state.pop(code, None)
        changed = True
    # 兼容可能按内部字段保存的节点
    if code:
        to_remove = []
        for key, val in state.items():
            if isinstance(val, dict) and str(val.get("symbol", "")).strip().upper() == code:
                to_remove.append(key)
        for key in to_remove:
            state.pop(key, None)
            changed = True
    if changed:
        write_state(state)


def current_time_text() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        if isinstance(value, str):
            value = value.strip()
            if value == "":
                return default
        return float(value)
    except Exception:
        return default


def normalize_symbol_input(symbol: str) -> str:
    s = (symbol or "").strip().upper().replace(" ", "")
    if not s:
        return s
    if s.startswith(("SH", "SZ", "HK")):
        return s
    if s.isdigit():
        if len(s) == 6:
            return f"SH{s}" if s.startswith("6") else f"SZ{s}"
        if len(s) <= 5:
            return f"HK{s.zfill(5)}"
    return s


def symbol_options(config: Dict[str, Any]) -> List[Tuple[str, str]]:
    result: List[Tuple[str, str]] = [("COMMON_BACKTEST_CONFIG", "通用回测参数")]
    etf_cfg = config.get("ETF_CONFIG", {}) or {}
    for name, item in etf_cfg.items():
        symbol = str(item.get("symbol", "")).strip()
        result.append((name, f"{name} ({symbol})" if symbol else name))
    return result


def get_section(config: Dict[str, Any], selected: str) -> Dict[str, Any]:
    if selected == "COMMON_BACKTEST_CONFIG":
        return config.get("COMMON_BACKTEST_CONFIG", {}) or {}
    return (config.get("ETF_CONFIG", {}) or {}).get(selected, {}) or {}


def set_section(config: Dict[str, Any], selected: str, section: Dict[str, Any]) -> None:
    if selected == "COMMON_BACKTEST_CONFIG":
        config["COMMON_BACKTEST_CONFIG"] = section
    else:
        config.setdefault("ETF_CONFIG", {})
        config["ETF_CONFIG"][selected] = section


def latest_status_for(selected: str, state: Dict[str, Any]) -> str:
    if selected == "COMMON_BACKTEST_CONFIG":
        return "通用回测参数无实时状态。"
    item = state.get(selected, {}) if isinstance(state, dict) else {}
    txt = str(item.get("last_status_msg", "暂无最新状态。")).strip()
    if txt.lower().startswith("last_status_msg"):
        txt = txt.split(":", 1)[-1].strip()
    return txt or "暂无最新状态。"


def convert_form_value(key: str, value: str) -> Any:
    value = value.strip()
    if key in {"symbol", "strategy_run", "box_grid_enabled", "base_units", "target_units", "current_units"}:
        return value
    if key == "pyramid_weights":
        if not value:
            return []
        return [float(x.strip()) for x in value.split(",") if x.strip()]
    if key in {"sideways_window_30", "sideways_window_60", "pyramid_steps"}:
        return int(float(value or 0))
    if value == "":
        return ""
    try:
        return float(value)
    except Exception:
        return value


def get_meta_from_state(selected: str, state: Dict[str, Any]) -> Dict[str, Any]:
    if selected == "COMMON_BACKTEST_CONFIG":
        return {"current_price": "", "last_time": ""}
    node = state.get(selected, {}) if isinstance(state, dict) else {}
    return {
        "current_price": node.get("last_price", ""),
        "last_time": node.get("last_time", ""),
    }


def build_grouped_fields(section: Dict[str, Any]) -> List[Dict[str, Any]]:
    grouped = []
    for group in FIELD_GROUPS:
        item_rows = []
        for key, label, field_type in group["items"]:
            raw = section.get(key, "")
            if isinstance(raw, list):
                display = ", ".join(str(x) for x in raw)
            elif isinstance(raw, bool):
                display = "true" if raw else "false"
            else:
                display = "" if raw is None else str(raw)
            item_rows.append(
                {
                    "key": key,
                    "label": label,
                    "type": field_type,
                    "value": display,
                    "readonly": True,
                    "options": SELECT_FIELD_OPTIONS.get(key, []),
                    "help": PARAM_HELP.get(key, ""),
                }
            )
        grouped.append({"id": group["id"], "title": group["title"], "items": item_rows})
    return grouped


def build_new_symbol_section(config: Dict[str, Any], symbol: str) -> Dict[str, Any]:
    common = deepcopy(config.get("COMMON_BACKTEST_CONFIG", {}) or {})
    normalize_config({"COMMON_BACKTEST_CONFIG": common})
    common["symbol"] = symbol
    common["strategy_run"] = "no"
    common["box_grid_enabled"] = "no"
    common.setdefault("current_units", common.get("base_units", ""))
    common.setdefault("current_avg_cost", 0.0)
    return common


def _artifact_url(path: Path) -> str:
    return url_for("download_artifact", path=str(path))


def _strip_backtest_explanation(text: str) -> str:
    if not text:
        return text
    lines = []
    for line in text.splitlines():
        s = line.strip()
        if s.startswith('$ /root/dcf/.venv/bin/python '):
            continue
        lines.append(line)
    text = "\n".join(lines).strip()
    marker = "\n说明："
    if marker in text:
        text = text.split(marker, 1)[0].rstrip()
    return text


def parse_backtest_output(text: str) -> Dict[str, Any]:
    summary_cards: List[Tuple[str, str]] = []
    files: Dict[str, Dict[str, str]] = {}
    if not text:
        return {"summary_cards": summary_cards, "files": files}
    kv: Dict[str, str] = {}
    artifact_paths: Dict[str, Path] = {}
    for line in text.splitlines():
        line_s = line.strip()
        m = re.match(r"^(日志|交易明细|事件明细):\s*(.+)$", line_s)
        if m:
            label = m.group(1)
            path = Path(m.group(2).strip())
            if path.exists():
                artifact_paths[label] = path
            continue
        if ":" in line_s:
            key, value = line_s.split(":", 1)
            key = key.strip()
            value = value.strip()
            if key in SUMMARY_KEYS or key in {"买入次数", "卖出次数", "分红事件", "拆股事件"}:
                kv[key] = value
    trade_path = artifact_paths.get("交易明细") or artifact_paths.get("日志")
    if trade_path and trade_path.exists():
        files["交易日志"] = {"name": "交易日志", "path": str(trade_path), "url": _artifact_url(trade_path)}
    def add(label: str, value: str):
        if value != "":
            summary_cards.append((label, value))
    if kv.get("买入次数") or kv.get("卖出次数"):
        add("买入/卖出次数", f"{kv.get('买入次数', '0')} | {kv.get('卖出次数', '0')}")
    if kv.get("分红事件") or kv.get("拆股事件"):
        add("分红/拆股事件", f"{kv.get('分红事件', '0')} | {kv.get('拆股事件', '0')}")
    for key in [
        "综合收益率(参考)", "个股收益(持仓部分)", "最大回撤(参考)",
        "已实现收益贡献(参考)", "浮动收益贡献(参考)",
        "期末持仓(成本口径)", "期末估算市值权重",
        "首次建仓日", "首次建仓原始价", "首次建仓复权价",
        "最新原始价", "最新复权价"
    ]:
        if key in kv:
            add(key, kv[key])
    return {"summary_cards": summary_cards, "files": files}

def run_backtest(symbol: str, days: int, base_units: str, target_units: str) -> Dict[str, Any]:
    if not BACKTEST_FILE.exists():
        return {"output": "❌ 未找到 backtest_dcf.py", "summary_cards": [], "files": {}}
    symbol = normalize_symbol_input(symbol)
    cmd = [
        sys.executable,
        str(BACKTEST_FILE),
        "--config",
        str(CONFIG_FILE),
        "--symbol",
        symbol,
        "--days",
        str(days),
    ]
    if base_units.strip():
        cmd.extend(["--base-units", base_units.strip()])
    if target_units.strip():
        cmd.extend(["--target-units", target_units.strip()])
    try:
        result = subprocess.run(
            cmd,
            cwd=str(BASE_DIR),
            capture_output=True,
            text=True,
            timeout=300,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return {"output": "❌ 回测超时，请缩短天数或检查网络。", "summary_cards": [], "files": {}}

    clean_stdout = _strip_backtest_explanation((result.stdout or "").strip())
    parts = []
    if clean_stdout:
        parts.append(clean_stdout)
    if result.stderr:
        parts.append("[stderr]\n" + result.stderr.strip())
    if result.returncode != 0 and not result.stderr and not clean_stdout:
        parts.append(f"❌ 回测失败，退出码={result.returncode}")
    output = "\n\n".join(x for x in parts if x)
    parsed = parse_backtest_output(clean_stdout)
    return {"output": output, **parsed}


def analyze_total_profit() -> str:
    import csv

    config = read_yaml()
    state = read_state()
    etf_config = config.get("ETF_CONFIG", {}) if isinstance(config, dict) else {}

    def get_mode_by_name(name: str) -> str:
        cfg = etf_config.get(name, {}) if isinstance(etf_config, dict) else {}
        base = cfg.get("base_units", 0)
        target = cfg.get("target_units", 0)
        if isinstance(base, str) and base.strip().endswith("%"):
            return "percent"
        if isinstance(target, str) and target.strip().endswith("%"):
            return "percent"
        try:
            if 0 <= float(base) <= 1 and 0 <= float(target) <= 1:
                return "percent"
        except Exception:
            pass
        return "absolute"

    def parse_dt(s: str):
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y.%m.%d.%H:%M", "%Y-%m-%d", "%Y/%m/%d %H:%M:%S"):
            try:
                return datetime.strptime(s, fmt)
            except Exception:
                pass
        return None

    if not TRADE_LOG_FILE.exists():
        return "未找到 trade_log.csv，暂无收益分析数据。"

    with TRADE_LOG_FILE.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    rows.sort(key=lambda r: parse_dt(r.get("date", "")) or datetime.min)
    if not rows:
        return "trade_log.csv 为空。"

    class DCFStat:
        def __init__(self, name: str, symbol: str, mode: str):
            self.name = name
            self.symbol = symbol
            self.mode = mode
            self.trade_count = 0
            self.position = 0.0
            self.avg_cost = 0.0
            self.realized_total = 0.0
            self.total_investment = 0.0

        def process_trade(self, row: Dict[str, str]) -> None:
            price = safe_float(row.get("price", 0))
            qty = safe_float(row.get("qty", 0))
            side = (row.get("side", "") or "").upper()
            pos_after = safe_float(row.get("pos_after", 0))
            avg_cost_before = safe_float(row.get("avg_cost_before", 0))
            avg_cost_after = safe_float(row.get("avg_cost_after", 0))
            self.trade_count += 1
            self.position = pos_after
            if avg_cost_after > 0:
                self.avg_cost = avg_cost_after
            if side == "BUY" and self.mode == "absolute":
                self.total_investment += price * qty
            elif side == "SELL":
                if self.mode == "absolute":
                    self.realized_total += (price - avg_cost_before) * qty if avg_cost_before > 0 else 0.0
                else:
                    self.realized_total += qty * (price / avg_cost_before - 1.0) if avg_cost_before > 0 else 0.0

        def get_current_price(self) -> float:
            d = state.get(self.name, {}) if isinstance(state, dict) else {}
            return safe_float(d.get("last_price", 0))

        def get_current_value_or_weight(self) -> Tuple[float, float]:
            price = self.get_current_price()
            if self.mode == "absolute":
                current_value = self.position * price if price > 0 else self.position * self.avg_cost
                floating = (price - self.avg_cost) * self.position if self.position > 0 and self.avg_cost > 0 and price > 0 else 0.0
                return current_value, floating
            if self.position <= 0:
                return 0.0, 0.0
            if price > 0 and self.avg_cost > 0:
                market_weight = self.position * price / self.avg_cost
                floating = self.position * (price / self.avg_cost - 1.0)
            else:
                market_weight = self.position
                floating = 0.0
            return market_weight, floating

    dcf_stats: Dict[Tuple[str, str], Any] = {}
    for row in rows:
        name = (row.get("dcf_name", "") or "UNKNOWN").strip() or "UNKNOWN"
        symbol = (row.get("symbol", "") or "").strip()
        key = (name, symbol)
        if key not in dcf_stats:
            dcf_stats[key] = DCFStat(name, symbol, get_mode_by_name(name))
        dcf_stats[key].process_trade(row)

    out: List[str] = ["=" * 60, "DCF 策略收益分析", "=" * 60]
    abs_total_realized = 0.0
    abs_total_investment = 0.0
    abs_total_current_value = 0.0
    pct_total_realized = 0.0
    pct_total_floating = 0.0
    pct_total_market_weight = 0.0

    for (name, symbol), stat in sorted(dcf_stats.items(), key=lambda x: x[0][0]):
        out.extend(["", "=" * 50, f"标的: {name} ({symbol})", "-" * 50])
        current_price = stat.get_current_price()
        current_metric, floating_metric = stat.get_current_value_or_weight()
        if stat.mode == "absolute":
            out.append(f"总投入资金: {stat.total_investment:,.2f}")
            out.append(f"已实现收益: {stat.realized_total:,.2f}")
            out.append(f"当前持仓市值: {current_metric:,.2f}")
            abs_total_realized += stat.realized_total
            abs_total_investment += stat.total_investment
            abs_total_current_value += current_metric
        else:
            out.append(f"当前持仓(成本口径): {stat.position * 100:.2f}%")
            out.append(f"当前价格: {current_price:.4f}" if current_price > 0 else "当前价格: -")
            out.append(f"已实现收益贡献: {stat.realized_total * 100:.2f}%")
            out.append(f"浮动收益贡献: {floating_metric * 100:.2f}%")
            out.append(f"综合收益贡献: {(stat.realized_total + floating_metric) * 100:.2f}%")
            pct_total_realized += stat.realized_total
            pct_total_floating += floating_metric
            pct_total_market_weight += current_metric

    out.extend(["", "=" * 60, "总体汇总", "=" * 60])
    if abs_total_investment > 0:
        total_assets = abs_total_current_value + abs_total_realized
        out.append("[股数模式]")
        out.append(f"总投入资金: {abs_total_investment:,.2f}")
        out.append(f"总已实现收益: {abs_total_realized:,.2f}")
        out.append(f"当前持仓市值: {abs_total_current_value:,.2f}")
        out.append(f"总资产: {total_assets:,.2f}")
    if abs(pct_total_market_weight) > 1e-12 or abs(pct_total_realized) > 1e-12 or abs(pct_total_floating) > 1e-12:
        out.append("[百分比模式]")
        out.append(f"当前估算市值权重合计: {pct_total_market_weight * 100:.2f}%")
        out.append(f"已实现收益贡献合计: {pct_total_realized * 100:.2f}%")
        out.append(f"浮动收益贡献合计: {pct_total_floating * 100:.2f}%")
        out.append(f"综合收益贡献合计: {(pct_total_realized + pct_total_floating) * 100:.2f}%")
    return "\n".join(out)


@app.before_request
def require_login() -> Any:
    if request.endpoint in {"login", "static", "download_artifact"}:
        return None
    if not session.get("logged_in"):
        return redirect(url_for("login"))
    return None


@app.route("/login", methods=["GET", "POST"])
def login():
    cfg = load_web_config()
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        stored_user = cfg.get("admin_username", "admin")
        stored_hash = cfg.get("password_hash", "")
        if username == stored_user and stored_hash and check_password_hash(stored_hash, password):
            session["logged_in"] = True
            session["username"] = username
            return redirect(url_for("status_page"))
        flash("用户名或密码错误", "error")
    return render_template("login.html", app_name=APP_DISPLAY_NAME, domain=cfg.get("domain", ""))


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/download-artifact")
def download_artifact():
    path_text = request.args.get("path", "").strip()
    if not path_text:
        abort(404)
    p = Path(path_text).expanduser().resolve()
    allowed_roots = [BACKTEST_OUT_DIR.resolve(), BASE_DIR.resolve()]
    if not any(str(p).startswith(str(root) + "/") or p == root for root in allowed_roots):
        abort(403)
    if not p.exists() or not p.is_file():
        abort(404)
    return send_file(p, as_attachment=True, download_name=p.name)


def _selected_key(config: Dict[str, Any]) -> str:
    options = symbol_options(config)
    allowed = {key for key, _ in options}
    requested = (request.args.get("symbol_key", "") or "").strip()
    if requested and requested in allowed:
        session["selected_symbol_key"] = requested
        return requested
    stored = str(session.get("selected_symbol_key", "")).strip()
    if stored in allowed:
        return stored
    fallback = options[0][0] if options else "COMMON_BACKTEST_CONFIG"
    session["selected_symbol_key"] = fallback
    return fallback


def build_symbol_cards(config: Dict[str, Any], selected: str) -> List[Dict[str, str]]:
    etf_cfg = config.get("ETF_CONFIG", {}) or {}
    cards = [{"key": "COMMON_BACKTEST_CONFIG", "label": "通用回测参数", "symbol": "", "active": selected == "COMMON_BACKTEST_CONFIG"}]
    for name, item in etf_cfg.items():
        cards.append({"key": name, "label": name, "symbol": str(item.get("symbol", "")).strip(), "active": selected == name})
    return cards


def _base_context(config: Dict[str, Any], selected: str) -> Dict[str, Any]:
    state = read_state()
    section = get_section(config, selected)
    meta = get_meta_from_state(selected, state)
    grouped_fields = build_grouped_fields(section)
    bt_symbol_default = normalize_symbol_input(section.get("symbol", "")) if selected != "COMMON_BACKTEST_CONFIG" else ""
    common = config.get("COMMON_BACKTEST_CONFIG", {}) or {}
    bt_base_default = str(section.get("base_units", common.get("base_units", "2.5%")))
    bt_target_default = str(section.get("target_units", common.get("target_units", "5%")))
    current_symbol = str(section.get("symbol", "")).strip()
    return {
        "app_name": APP_DISPLAY_NAME,
        "selected": selected,
        "selected_label": "通用回测参数" if selected == "COMMON_BACKTEST_CONFIG" else selected,
        "selected_symbol_code": current_symbol,
        "section": section,
        "status_text": latest_status_for(selected, state),
        "grouped_fields": grouped_fields,
        "current_time": current_time_text(),
        "current_price": meta.get("current_price", ""),
        "last_time": meta.get("last_time", ""),
        "bt_symbol_default": bt_symbol_default,
        "bt_base_default": bt_base_default,
        "bt_target_default": bt_target_default,
        "is_common": selected == "COMMON_BACKTEST_CONFIG",
        "nav_items": PAGE_TITLES,
        "param_help": PARAM_HELP,
        "backtest_help_text": BACKTEST_HELP_TEXT,
        "symbol_cards": build_symbol_cards(config, selected),
    }


def _save_all_params(config: Dict[str, Any], selected: str) -> None:
    section = get_section(config, selected).copy()
    for group in FIELD_GROUPS:
        for key, _, _ in group["items"]:
            if key in request.form:
                section[key] = convert_form_value(key, request.form.get(key, ""))
    section.pop("fee_rate", None)
    section.pop("slippage_bp", None)
    section.pop("pyramid_enabled", None)
    if section.get("box_grid_enabled") not in {"yes", "no"}:
        section["box_grid_enabled"] = "no"
    if section.get("strategy_run") not in {"yes", "no"}:
        section["strategy_run"] = "no"
    set_section(config, selected, section)
    write_yaml(config)


def _handle_symbol_actions(config: Dict[str, Any], selected: str):
    action = request.form.get("action", "")
    if action == "set_symbol":
        new_selected = (request.form.get("symbol_key", "") or "").strip()
        session["selected_symbol_key"] = new_selected or selected
        return redirect(url_for("symbols_page"))
    if action == "add_symbol":
        symbol_name = (request.form.get("new_name", "") or "").strip()
        symbol_code = normalize_symbol_input(request.form.get("new_symbol", ""))
        if not symbol_name or not symbol_code:
            flash("请填写标的名称和代码。", "error")
        else:
            etf_cfg = config.setdefault("ETF_CONFIG", {}) or {}
            if symbol_name in etf_cfg:
                flash("该名称已存在，请换一个。", "error")
            else:
                config.setdefault("ETF_CONFIG", {})[symbol_name] = build_new_symbol_section(config, symbol_code)
                write_yaml(config)
                flash(f"已新增标的：{symbol_name} ({symbol_code})", "success")
                return redirect(url_for("symbols_page", symbol_key=symbol_name))
    elif action == "delete_symbol":
        if selected == "COMMON_BACKTEST_CONFIG":
            flash("通用回测参数不可删除。", "error")
        else:
            etf_cfg = config.get("ETF_CONFIG", {}) or {}
            if selected in etf_cfg:
                symbol_code = str((etf_cfg.get(selected) or {}).get("symbol", "")).strip().upper()
                del etf_cfg[selected]
                write_yaml(config)
                delete_symbol_state(selected, symbol_code)
                flash(f"已删除标的：{selected}", "success")
                return redirect(url_for("symbols_page", symbol_key="COMMON_BACKTEST_CONFIG"))
            flash("未找到要删除的标的。", "error")
    return None


@app.route("/")
def home_redirect():
    return redirect(url_for("status_page", symbol_key=request.args.get("symbol_key", "")))


@app.route("/symbols", methods=["GET", "POST"])
def symbols_page():
    config = read_yaml()
    selected = _selected_key(config)
    if request.method == "POST":
        redirect_resp = _handle_symbol_actions(config, selected)
        if redirect_resp is not None:
            return redirect_resp
        config = read_yaml()
        selected = _selected_key(config)
    ctx = _base_context(config, selected)
    ctx.update({"page_name": "symbols"})
    return render_template("dashboard.html", **ctx)


@app.route("/status", methods=["GET"])
def status_page():
    config = read_yaml()
    selected = _selected_key(config)
    ctx = _base_context(config, selected)
    ctx.update({"page_name": "status"})
    return render_template("dashboard.html", **ctx)


@app.route("/params", methods=["GET", "POST"])
def params_page():
    config = read_yaml()
    selected = _selected_key(config)
    if request.method == "POST" and request.form.get("action") == "save_params":
        _save_all_params(config, selected)
        flash("参数已保存到 dcf.yaml", "success")
        return redirect(url_for("params_page"))
    ctx = _base_context(config, selected)
    ctx.update({"page_name": "params"})
    return render_template("dashboard.html", **ctx)


@app.route("/backtest", methods=["GET", "POST"])
def backtest_page():
    config = read_yaml()
    selected = _selected_key(config)
    backtest_output = ""
    backtest_cards = []
    backtest_files = {}
    if request.method == "POST" and request.form.get("action") == "run_backtest":
        bt_symbol = normalize_symbol_input(request.form.get("bt_symbol", "") or _base_context(config, selected)["bt_symbol_default"])
        bt_base = (request.form.get("bt_base_units", "") or "").strip()
        bt_target = (request.form.get("bt_target_units", "") or "").strip()
        bt_days = int(request.form.get("bt_days", "800") or "800")
        if not bt_symbol:
            flash("请填写回测代码。", "error")
        else:
            result = run_backtest(bt_symbol, bt_days, bt_base, bt_target)
            backtest_output = result.get("output", "")
            backtest_cards = result.get("summary_cards", [])
            backtest_files = result.get("files", {})
            flash("回测执行完成。", "success")
    ctx = _base_context(config, selected)
    ctx.update({"page_name": "backtest", "backtest_output": backtest_output, "backtest_cards": backtest_cards, "backtest_files": backtest_files})
    return render_template("dashboard.html", **ctx)


@app.route("/analysis", methods=["GET", "POST"])
def analysis_page():
    config = read_yaml()
    selected = _selected_key(config)
    analysis_output = ""
    if request.method == "POST" and request.form.get("action") == "analyze_profit":
        analysis_output = analyze_total_profit()
        flash("总收益分析已生成。", "success")
    ctx = _base_context(config, selected)
    ctx.update({"page_name": "analysis", "analysis_output": analysis_output})
    return render_template("dashboard.html", **ctx)


if __name__ == "__main__":
    cfg = load_web_config()
    app.run(host="127.0.0.1", port=int(cfg.get("internal_port", 1819)), debug=False)
